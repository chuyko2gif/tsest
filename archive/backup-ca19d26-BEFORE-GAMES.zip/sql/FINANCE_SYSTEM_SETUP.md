# 💰 Полная настройка финансовой системы THQ Label

## 📋 Что включает финансовая система

1. **Таблица транзакций** (`transactions`) - история всех финансовых операций
2. **Заявки на вывод** (`withdrawal_requests`) - запросы пользователей на вывод средств
3. **Автоматическое управление балансами** - триггеры для начислений и списаний
4. **Интеграция с payouts** - автоматическое начисление при создании выплаты
5. **Realtime обновления** - мгновенные уведомления о транзакциях

---

## 🚀 Быстрый старт (первичная настройка)

### Шаг 1: Запустите полную настройку финансовой системы

```sql
-- Выполните этот файл в Supabase SQL Editor:
sql/FULL_FINANCE_SETUP.sql
```

Этот скрипт:
- ✅ Создаст таблицу `transactions`
- ✅ Настроит таблицу `withdrawal_requests` (если её нет)
- ✅ Создаст функцию `create_transaction()` для управления балансами
- ✅ Настроит триггеры для автоматических начислений/списаний
- ✅ Включит Realtime для мгновенных обновлений
- ✅ Настроит RLS политики безопасности

### Шаг 2: Проверьте настройку

После выполнения скрипта вы должны увидеть:

```
✅ Таблица транзакций создана!
✅ Таблица withdrawal_requests готова!
✅ Функция create_transaction создана!
✅ Интеграция с payouts настроена!
✅ Интеграция с withdrawal_requests настроена!
✅ Realtime настроен!
🎉 ФИНАНСОВАЯ СИСТЕМА ПОЛНОСТЬЮ НАСТРОЕНА!
```

---

## 🔄 Как работает система

### 1. Начисления (Payouts)

Когда создается новая выплата в таблице `payouts`:

```sql
INSERT INTO payouts (user_id, amount, release_title, ...)
VALUES (...);
```

**Автоматически:**
- 💰 Создается транзакция типа `payout`
- 📈 Баланс пользователя увеличивается на сумму выплаты
- 📝 Записывается история в `transactions`

### 2. Заявки на вывод (Withdrawals)

Когда пользователь создает заявку на вывод:

```sql
INSERT INTO withdrawal_requests (user_id, amount, bank_name, ...)
VALUES (...);
```

**Автоматически:**
- 💸 Создается транзакция типа `withdrawal`
- 📉 Баланс пользователя уменьшается на сумму вывода
- 🔒 Средства резервируются до обработки заявки
- ❌ Если средств недостаточно - операция отклоняется

### 3. Отклонение заявки

Когда админ отклоняет заявку на вывод:

```sql
UPDATE withdrawal_requests 
SET status = 'rejected', admin_comment = '...'
WHERE id = '...';
```

**Автоматически:**
- ↩️ Создается транзакция типа `refund`
- 📈 Баланс пользователя восстанавливается
- 📝 Записывается причина возврата

---

## 🗃️ Структура таблиц

### Таблица `transactions`

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | SERIAL | ID транзакции |
| `user_id` | UUID | ID пользователя |
| `type` | TEXT | Тип: `payout`, `withdrawal`, `refund`, `adjustment`, `bonus` |
| `amount` | DECIMAL | Сумма транзакции (всегда положительная) |
| `balance_before` | DECIMAL | Баланс до операции |
| `balance_after` | DECIMAL | Баланс после операции |
| `description` | TEXT | Описание транзакции |
| `reference_id` | INTEGER | ID связанной записи (payout/withdrawal) |
| `reference_table` | TEXT | Таблица: `payouts` или `withdrawal_requests` |
| `metadata` | JSONB | Дополнительные данные |
| `created_by` | UUID | Кто создал (для ручных операций) |
| `created_at` | TIMESTAMPTZ | Время создания |

### Типы транзакций

- `payout` - начисление за релиз (баланс +)
- `withdrawal` - вывод средств (баланс -)
- `refund` - возврат средств при отклонении заявки (баланс +)
- `adjustment` - ручная корректировка баланса админом (+ или -)
- `bonus` - бонусное начисление (баланс +)

---

## 🛠️ Полезные запросы

### Посмотреть историю транзакций пользователя

```sql
SELECT 
  id,
  type,
  amount,
  balance_after,
  description,
  created_at
FROM transactions
WHERE user_id = 'user-uuid-here'
ORDER BY created_at DESC;
```

### Посмотреть текущий баланс и последнюю транзакцию

```sql
SELECT 
  p.email,
  p.balance as current_balance,
  t.amount as last_transaction_amount,
  t.type as last_transaction_type,
  t.created_at as last_transaction_date
FROM profiles p
LEFT JOIN LATERAL (
  SELECT * FROM transactions 
  WHERE user_id = p.id 
  ORDER BY created_at DESC 
  LIMIT 1
) t ON true
WHERE p.id = 'user-uuid-here';
```

### Статистика по выводам

```sql
SELECT 
  status,
  COUNT(*) as count,
  SUM(amount) as total_amount
FROM withdrawal_requests
GROUP BY status;
```

---

## 🔥 Сброс финансовой системы

⚠️ **ВНИМАНИЕ**: Это удалит ВСЕ финансовые данные!

```sql
-- Выполните файл:
sql/reset_all_balances.sql
```

Что будет удалено:
- ❌ Все транзакции
- ❌ Все заявки на вывод
- ❌ Все выплаты
- ❌ Все балансы будут обнулены

---

## 📊 Мониторинг системы

### Проверить работу триггеров

```sql
SELECT 
  trigger_name,
  event_object_table,
  action_timing,
  event_manipulation
FROM information_schema.triggers
WHERE trigger_name LIKE 'trg_%'
ORDER BY event_object_table;
```

### Проверить функции

```sql
SELECT 
  routine_name,
  routine_type
FROM information_schema.routines
WHERE routine_name IN (
  'create_transaction',
  'on_payout_created',
  'on_withdrawal_request_created',
  'on_withdrawal_request_updated'
);
```

### Проверить Realtime

```sql
SELECT 
  schemaname,
  tablename
FROM pg_publication_tables
WHERE pubname = 'supabase_realtime'
  AND tablename IN ('transactions', 'withdrawal_requests', 'payouts');
```

---

## 🐛 Устранение неполадок

### Проблема: Триггеры не срабатывают

**Решение**: Пересоздайте триггеры

```sql
-- Запустите снова:
sql/FULL_FINANCE_SETUP.sql
```

### Проблема: Балансы не обновляются

**Проверьте**:
1. Существует ли функция `create_transaction`
2. Включены ли триггеры на таблицах
3. Нет ли ошибок в логах Supabase

### Проблема: Пользователь не может создать заявку на вывод

**Причины**:
- Недостаточно средств на балансе
- Сумма меньше минимальной (1000)
- RLS политики блокируют доступ

---

## 📝 Примечания

1. **Безопасность**: Все транзакции проходят через функцию `create_transaction()`, которая проверяет баланс и предотвращает уход в минус

2. **Атомарность**: Все операции выполняются в транзакциях - либо все изменения применяются, либо откатываются

3. **История**: Каждое изменение баланса фиксируется в `transactions` с балансом до и после

4. **RLS**: Пользователи видят только свои транзакции и заявки. Админы видят всё.

---

## ✅ Чеклист готовности

- [ ] Выполнен `FULL_FINANCE_SETUP.sql`
- [ ] Все триггеры создаты и работают
- [ ] Realtime включен для `transactions` и `withdrawal_requests`
- [ ] RLS политики настроены
- [ ] Протестирована интеграция с payouts
- [ ] Протестированы заявки на вывод
- [ ] Протестирован возврат при отклонении заявки

---

**🎉 Поздравляем! Финансовая система готова к использованию!**
