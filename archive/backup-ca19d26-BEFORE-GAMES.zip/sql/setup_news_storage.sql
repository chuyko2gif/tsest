-- ========================================
-- СОЗДАНИЕ STORAGE ДЛЯ КАРТИНОК НОВОСТЕЙ
-- ========================================
-- Этот скрипт настраивает хранилище для картинок новостей в Supabase Storage

-- ⚠️ ВАЖНО: Эти команды выполняются в Supabase Dashboard, а не в SQL Editor!

-- ========================================
-- ИНСТРУКЦИЯ ПО НАСТРОЙКЕ STORAGE
-- ========================================

-- ШАГ 1: Создать bucket для картинок новостей
-- -------------------------------------------
-- 1. Перейди в Supabase Dashboard → Storage
-- 2. Нажми "Create bucket"
-- 3. Заполни:
--    - Name: news-images
--    - Public bucket: ✓ (галочка) - чтобы картинки были доступны всем
-- 4. Нажми "Create"

-- ШАГ 2: Настроить политики доступа
-- -------------------------------------------
-- После создания bucket нажми на него и перейди в Policies

-- ПОЛИТИКА 1: Публичное чтение
-- Название: "Public read for news images"
-- Allowed operation: SELECT
-- Policy definition:
CREATE POLICY "Public read for news images"
ON storage.objects FOR SELECT
USING (bucket_id = 'news-images');

-- ПОЛИТИКА 2: Админы могут загружать
-- Название: "Admins can upload news images"  
-- Allowed operation: INSERT
-- Policy definition:
CREATE POLICY "Admins can upload news images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'news-images' AND
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

-- ПОЛИТИКА 3: Админы могут удалять
-- Название: "Admins can delete news images"
-- Allowed operation: DELETE
-- Policy definition:
CREATE POLICY "Admins can delete news images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'news-images' AND
  EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  )
);

-- ========================================
-- ПРОВЕРКА
-- ========================================

-- Проверь что bucket создан
-- Выполни в SQL Editor:
SELECT 
  id,
  name,
  public
FROM storage.buckets
WHERE name = 'news-images';

-- Если видишь строку с name = 'news-images' и public = true - всё настроено правильно!

-- ========================================
-- ДОПОЛНИТЕЛЬНО: ОГРАНИЧЕНИЯ
-- ========================================

-- Если нужно ограничить размер файлов или типы:
-- Это настраивается на уровне приложения (уже сделано в коде):
-- - Максимальный размер: 5MB
-- - Разрешённые типы: image/*

-- ========================================
-- ИСПОЛЬЗОВАНИЕ
-- ========================================

-- После настройки Storage:
-- 1. Зайди в админ-панель → Новости
-- 2. В поле "Картинка" нажми "📤 Загрузить изображение с компьютера"
-- 3. Выбери файл - он загрузится в Supabase Storage
-- 4. URL автоматически подставится в поле

-- Формат URL будет:
-- https://[project-ref].supabase.co/storage/v1/object/public/news-images/news/[filename]
