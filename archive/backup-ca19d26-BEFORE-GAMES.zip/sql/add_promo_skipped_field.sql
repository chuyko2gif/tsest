-- ============================================
-- 🎯 ДОБАВЛЕНИЕ ПОЛЯ is_promo_skipped
-- Дата: Декабрь 2025
-- 
-- ЧТО ДЕЛАЕТ:
-- 1. Добавляет поле is_promo_skipped для отслеживания 
--    пропущенного шага промо
-- ============================================

-- ШАГ 1: Добавляем поле is_promo_skipped
-- ============================================

ALTER TABLE public.releases_basic 
ADD COLUMN IF NOT EXISTS is_promo_skipped BOOLEAN DEFAULT false;

ALTER TABLE public.releases_exclusive 
ADD COLUMN IF NOT EXISTS is_promo_skipped BOOLEAN DEFAULT false;

-- ШАГ 2: Комментарии для документации
-- ============================================

COMMENT ON COLUMN releases_basic.is_promo_skipped IS 'Флаг: пропущен ли шаг промо при создании релиза';
COMMENT ON COLUMN releases_exclusive.is_promo_skipped IS 'Флаг: пропущен ли шаг промо при создании релиза';

-- ============================================
-- ✅ ГОТОВО!
-- 
-- После выполнения:
-- - Поле is_promo_skipped доступно в обеих таблицах
-- - По умолчанию false (промо не пропущено)
-- ============================================
