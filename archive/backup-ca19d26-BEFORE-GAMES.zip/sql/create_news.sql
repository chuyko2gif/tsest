-- ========================================
-- СОЗДАНИЕ ТАБЛИЦЫ НОВОСТЕЙ THQ LABEL
-- ========================================
-- Этот скрипт создаёт всё необходимое для работы новостей:
-- ✓ Таблицу для хранения новостей
-- ✓ Права доступа (RLS) - кто может читать/создавать/редактировать
-- ✓ Автоматическое обновление даты изменения
-- ✓ Тестовую новость для проверки

-- ШАГ 1: Удаляем старую таблицу (если существует)
-- Это нужно для чистой установки
DROP TABLE IF EXISTS news CASCADE;

-- ШАГ 2: Создаём таблицу news
-- Здесь будут храниться все новости лейбла
CREATE TABLE news (
  id BIGSERIAL PRIMARY KEY,              -- Уникальный номер новости (автоматически)
  title TEXT NOT NULL,                   -- Заголовок новости (обязательное поле)
  content TEXT,                          -- Текст новости (можно оставить пустым)
  category TEXT DEFAULT 'Новость',       -- Категория: Новость, Релиз, Анонс, и т.д.
  image TEXT,                            -- Ссылка на картинку (необязательно)
  created_at TIMESTAMPTZ DEFAULT NOW(),  -- Дата создания (заполняется автоматически)
  updated_at TIMESTAMPTZ DEFAULT NOW()   -- Дата последнего изменения (обновляется автоматически)
);

-- ШАГ 3: Создаём индекс для быстрой работы
-- Это ускоряет загрузку новостей по дате
CREATE INDEX idx_news_created_at ON news(created_at DESC);

-- ШАГ 4: Включаем систему безопасности (RLS)
-- Row Level Security - защита на уровне строк
ALTER TABLE news ENABLE ROW LEVEL SECURITY;

-- ========================================
-- НАСТРОЙКА ПРАВ ДОСТУПА
-- ========================================

-- ПОЛИТИКА 1: Чтение новостей
-- КТО: Все пользователи (даже без регистрации)
-- ЧТО МОЖЕТ: Просматривать новости на странице /news
DROP POLICY IF EXISTS "Enable read for all" ON news;
CREATE POLICY "Enable read for all"
  ON news FOR SELECT
  USING (true);

-- ПОЛИТИКА 1: Чтение новостей
-- КТО: Все пользователи (даже без регистрации)
-- ЧТО МОЖЕТ: Просматривать новости на странице /news
DROP POLICY IF EXISTS "Enable read for all" ON news;
CREATE POLICY "Enable read for all"
  ON news FOR SELECT
  USING (true);

-- ПОЛИТИКА 2: Создание новостей
-- КТО: Только пользователи с ролью 'admin' в таблице profiles
-- ЧТО МОЖЕТ: Публиковать новые новости через админ-панель
DROP POLICY IF EXISTS "Enable insert for admins" ON news;
CREATE POLICY "Enable insert for admins"
  ON news FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- ПОЛИТИКА 3: Редактирование новостей
-- КТО: Только админы
-- ЧТО МОЖЕТ: Изменять текст, заголовок, категорию любой новости
DROP POLICY IF EXISTS "Enable update for admins" ON news;
CREATE POLICY "Enable update for admins"
  ON news FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- ПОЛИТИКА 4: Удаление новостей
-- КТО: Только админы
-- ЧТО МОЖЕТ: Полностью удалять новости из базы данных
DROP POLICY IF EXISTS "Enable delete for admins" ON news;
CREATE POLICY "Enable delete for admins"
  ON news FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- ========================================
-- АВТОМАТИЗАЦИЯ
-- ========================================

-- Функция для автоматического обновления даты изменения
-- Каждый раз при редактировании новости updated_at обновляется на текущее время
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Триггер: вызываем функцию при каждом UPDATE
DROP TRIGGER IF EXISTS update_news_updated_at ON news;
CREATE TRIGGER update_news_updated_at
  BEFORE UPDATE ON news
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ========================================
-- ТЕСТОВЫЕ ДАННЫЕ
-- ========================================

-- Создаём первую новость для проверки
INSERT INTO news (title, content, category, image) VALUES 
(
  'Добро пожаловать в thq label!',
  'Это первая новость в вашей системе.

## Что дальше?

- Перейдите в админ-панель
- Откройте вкладку "📰 Новости"
- Создайте свою первую новость
- Новость сразу появится на странице /news

Удачи!',
  'Обновление',
  'https://novayagazeta.ru/static/records/bec4ac4a0d544693a4f4414fe4d50a0d.jpeg'
);

-- ========================================
-- ПРОВЕРКА УСТАНОВКИ
-- ========================================

-- Показываем все созданные новости
SELECT 
  id AS "ID",
  title AS "Заголовок",
  category AS "Категория",
  created_at AS "Дата создания"
FROM news 
ORDER BY created_at DESC;
