# 🚀 Настройка системы релизов с поддержкой тикетов

## 📋 Порядок выполнения SQL скриптов

### Шаг 1: Создание таблицы релизов
Выполните: `create_releases_unified.sql`

Этот скрипт создаст:
- ✅ Таблицу `releases` с полной структурой
- ✅ Индексы для быстрого поиска
- ✅ RLS политики безопасности
- ✅ Функции для модерации и управления
- ✅ Триггеры для автообновления полей

### Шаг 2: Добавление связи с тикетами
Выполните: `add_release_id_to_tickets.sql`

Этот скрипт добавит:
- ✅ Поле `release_id` в таблицу `support_tickets`
- ✅ Foreign key связь с таблицей `releases`
- ✅ Индекс для оптимизации запросов
- ✅ Автоматическую проверку существования таблицы `releases`

## 🎯 Как выполнить

### В Supabase Dashboard:
1. Откройте **SQL Editor**
2. Создайте новый запрос
3. Скопируйте содержимое `create_releases_unified.sql`
4. Нажмите **Run**
5. После успешного выполнения повторите для `add_release_id_to_tickets.sql`

### Через командную строку (если есть доступ):
```bash
psql -h your-host -U postgres -d your-database -f sql/create_releases_unified.sql
psql -h your-host -U postgres -d your-database -f sql/add_release_id_to_tickets.sql
```

## ✨ Что получите после выполнения

### Для пользователей:
- Возможность выбирать релиз при создании тикета категории "Релизы"
- Отображение информации о релизе (обложка, артист, название) в тикете
- Быстрый переход к релизу из тикета

### Для администраторов:
- Видимость привязанного релиза в админ-панели тикетов
- Контекст обращения пользователя сразу виден
- Удобство модерации тикетов по релизам

## 🔧 Структура поля release_id

```sql
release_id UUID REFERENCES public.releases(id) ON DELETE SET NULL
```

- **Тип**: UUID
- **Nullable**: Да (необязательное поле)
- **Foreign Key**: Связь с таблицей releases
- **ON DELETE SET NULL**: При удалении релиза, поле обнуляется (тикет остается)

## 📊 Примеры использования

### Получить все тикеты по конкретному релизу:
```sql
SELECT * FROM support_tickets 
WHERE release_id = 'your-release-uuid'
ORDER BY created_at DESC;
```

### Получить тикеты с информацией о релизе:
```sql
SELECT 
  t.*,
  r.title as release_title,
  r.artist_name,
  r.cover_url as artwork_url
FROM support_tickets t
LEFT JOIN releases r ON t.release_id = r.id
WHERE t.user_id = 'your-user-id';
```

## ⚠️ Важные замечания

1. **Порядок выполнения критичен**: Сначала `releases`, потом `tickets`
2. **Проверка зависимостей**: Скрипт автоматически проверит наличие таблицы releases
3. **Безопасность**: Foreign key гарантирует целостность данных
4. **Производительность**: Индексы оптимизируют запросы

## 🐛 Устранение проблем

### Ошибка: "relation 'public.releases' does not exist"
**Решение**: Выполните сначала `create_releases_unified.sql`

### Ошибка: "column 'release_id' already exists"
**Решение**: Поле уже добавлено, миграция не требуется

### Ошибка: "permission denied"
**Решение**: Убедитесь что выполняете от пользователя с правами CREATE

## 📝 Откат изменений (если нужно)

```sql
-- Удалить поле release_id из tickets
ALTER TABLE support_tickets DROP COLUMN IF EXISTS release_id;

-- Удалить таблицу releases (ОСТОРОЖНО! Удалит все релизы)
DROP TABLE IF EXISTS releases CASCADE;
```

## ✅ Проверка успешной установки

```sql
-- Проверить структуру таблицы tickets
\d support_tickets

-- Проверить наличие индекса
SELECT indexname FROM pg_indexes 
WHERE tablename = 'support_tickets' 
AND indexname = 'idx_support_tickets_release_id';

-- Проверить foreign key
SELECT conname, conrelid::regclass, confrelid::regclass
FROM pg_constraint
WHERE conname LIKE '%release%';
```

---

**Дата создания**: 25 декабря 2025  
**Версия**: 1.0  
**Автор**: THQ Label Development Team
