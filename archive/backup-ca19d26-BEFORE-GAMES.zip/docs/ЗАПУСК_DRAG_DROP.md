# ⚡ ЗАПУСК DRAG & DROP - ПОШАГОВО

## 🎯 СДЕЛАЙ РОВНО ЭТО:

### 1️⃣ Открой Supabase

1. Зайди на **supabase.com**
2. Выбери свой проект
3. Слева найди **SQL Editor**
4. Нажми **"New Query"**

### 2️⃣ Скопируй и выполни SQL

1. Открой файл: **`sql/SIMPLE_DRAFT_ORDERING.sql`**
2. Скопируй **ВЕСЬ** код (Ctrl+A → Ctrl+C)
3. Вставь в Supabase SQL Editor (Ctrl+V)
4. Нажми **"RUN"** (или Ctrl+Enter)

### 3️⃣ Проверь результат

В консоли Supabase должно быть:
```
✅ Success. No rows returned
```

Если ошибка - напиши мне текст ошибки!

### 4️⃣ Перезапусти приложение

```bash
npm run dev
```

### 5️⃣ ТЕСТ

1. Открой кабинет
2. Перейди в **"Архив (Черновики)"**
3. Если черновиков нет - создай 2-3 штуки
4. **Перетащи черновик** мышью на новое место
5. **Обнови страницу** (F5)
6. ✅ Порядок должен сохраниться!

---

## ❗ ЕСЛИ НЕ РАБОТАЕТ

### Проблема: SQL не выполняется

**Удали старые данные:**
```sql
-- Выполни это в Supabase SQL Editor:
DROP FUNCTION IF EXISTS reorder_draft_release CASCADE;
ALTER TABLE releases_basic DROP COLUMN IF EXISTS draft_order;
ALTER TABLE releases_exclusive DROP COLUMN IF EXISTS draft_order;
```

Потом снова выполни `SIMPLE_DRAFT_ORDERING.sql`

### Проблема: Перетаскивание не сохраняется

**Проверь консоль браузера (F12):**
- Если ошибка `function reorder_draft_release does not exist` → SQL не выполнился
- Если ошибка `permission denied` → проблема с RLS политиками

**Проверь в SQL:**
```sql
-- Проверка наличия поля:
SELECT column_name FROM information_schema.columns 
WHERE table_name = 'releases_basic' AND column_name = 'draft_order';

-- Должно вернуть: draft_order
```

### Проблема: Пустота при перетаскивании

Это исправлено в коде. Перезапусти приложение:
```bash
# Останови сервер (Ctrl+C)
npm run dev
```

---

## 🎉 ДОЛЖНО РАБОТАТЬ!

После выполнения SQL скрипта:
- ✅ Поле `draft_order` добавлено
- ✅ Функция `reorder_draft_release()` создана
- ✅ Индексы для быстрой работы
- ✅ RLS политики обновлены

**Фронтенд уже готов** - просто выполни SQL!

---

## 📞 НУЖНА ПОМОЩЬ?

Напиши мне:
- Что именно не работает?
- Текст ошибки из консоли браузера (F12)
- Скриншот если есть

Я помогу!
