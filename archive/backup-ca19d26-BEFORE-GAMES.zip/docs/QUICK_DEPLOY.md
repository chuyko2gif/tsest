# 🚀 Быстрый деплой на Vercel

## Шаг 1: Регистрация на Vercel

1. Перейдите на https://vercel.com
2. Нажмите **"Sign Up"**
3. Выберите **"Continue with GitHub"**
4. Авторизуйте Vercel для доступа к вашим репозиториям

## Шаг 2: Подготовка Git репозитория

Если у вас еще нет Git репозитория:

```powershell
# Инициализация Git
git init

# Добавить все файлы
git add .

# Сделать первый коммит
git commit -m "Initial commit"
```

Затем создайте репозиторий на GitHub:
1. Перейдите на https://github.com/new
2. Создайте новый репозиторий (например, `thq-label`)
3. **НЕ** добавляйте README, .gitignore или license (они уже есть)

Подключите локальный репозиторий к GitHub:

```powershell
# Замените YOUR_USERNAME и YOUR_REPO на свои значения
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

## Шаг 3: Деплой на Vercel

1. **Войдите на Vercel** (https://vercel.com)
2. **Нажмите "Add New Project"**
3. **Импортируйте ваш GitHub репозиторий:**
   - Выберите репозиторий из списка
   - Если не видите - нажмите "Adjust GitHub App Permissions"
4. **Настройте проект:**
   - Framework Preset: **Next.js** (определится автоматически)
   - Root Directory: `./` (оставьте по умолчанию)
   - Build Command: `npm run build` (оставьте по умолчанию)
   - Output Directory: `.next` (оставьте по умолчанию)

## Шаг 4: Добавьте переменные окружения

⚠️ **ВАЖНО!** Перед деплоем добавьте переменные окружения:

В разделе **"Environment Variables"** добавьте:

```
NEXT_PUBLIC_SUPABASE_URL=ваш-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=ваш-публичный-ключ
SUPABASE_SERVICE_ROLE_KEY=ваш-секретный-ключ
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=ваш-email@gmail.com
SMTP_PASS=ваш-app-password
```

💡 **Где взять значения:**
- Supabase URL и ключи: в настройках вашего Supabase проекта (Settings → API)
- SMTP данные: если используете Gmail - создайте App Password в настройках Google Account

## Шаг 5: Деплой!

1. Нажмите **"Deploy"**
2. Подождите 2-3 минуты
3. Готово! 🎉

Ваш сайт будет доступен по адресу: `https://ваш-проект.vercel.app`

## 🔄 Автоматический редеплой

После первого деплоя:
- **Каждый push в main** → автоматически обновит продакшн
- **Pull request** → создаст preview-версию для тестирования

## 🌐 Кастомный домен (опционально)

1. В Vercel перейдите в **Settings → Domains**
2. Добавьте свой домен
3. Настройте DNS записи по инструкции Vercel

---

## ⚠️ Важные настройки Supabase

После деплоя обязательно добавьте домен Vercel в Supabase:

1. Откройте Supabase Dashboard
2. **Authentication → URL Configuration**
3. Добавьте в **Site URL**: `https://ваш-проект.vercel.app`
4. Добавьте в **Redirect URLs**:
   - `https://ваш-проект.vercel.app/**`
   - `https://ваш-проект.vercel.app/auth`

---

## 🐛 Решение проблем

### Ошибка при сборке
- Проверьте логи в Vercel Dashboard
- Убедитесь что все переменные окружения добавлены

### База данных не работает
- Проверьте что NEXT_PUBLIC_SUPABASE_URL правильный
- Проверьте что домен добавлен в Supabase

### Email не отправляется
- Проверьте SMTP настройки
- Для Gmail используйте App Password, не обычный пароль

---

## 📱 Поделиться ссылкой

После успешного деплоя можете сразу делиться ссылкой:
`https://ваш-проект.vercel.app`

Все могут смотреть и тестировать! 🚀
