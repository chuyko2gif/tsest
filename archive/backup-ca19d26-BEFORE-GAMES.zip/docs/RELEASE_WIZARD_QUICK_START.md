# 🚀 Release Wizard - Quick Start Guide

## Быстрая настройка за 5 минут

### Шаг 1: SQL Миграция ⚡
```bash
# 1. Открыть Supabase Dashboard → SQL Editor
# 2. Скопировать содержимое файла:
```
📄 `sql/add_release_wizard_fields.sql`

```bash
# 3. Выполнить SQL запрос
# 4. Проверить что все поля добавлены без ошибок
```

---

### Шаг 2: Создать Storage Buckets 📦

В Supabase Dashboard → Storage → New Bucket:

1. **release-covers** (Public ✅)
2. **release-audio** (Private ❌)
3. **release-promo** (Public ✅)  
4. **payment-receipts** (Private ❌)

Для каждого бакета настроить RLS политики согласно `docs/SUPABASE_STORAGE_SETUP.md`

---

### Шаг 3: Проверить переменные окружения 🔐

`.env.local`:
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
```

---

### Шаг 4: Создать тестовых пользователей 👥

```sql
-- В таблице profiles установить роли:

-- Basic пользователь (с оплатой)
UPDATE profiles 
SET role = 'basic' 
WHERE email = 'test-basic@example.com';

-- Exclusive пользователь (без оплаты)
UPDATE profiles 
SET role = 'exclusive' 
WHERE email = 'test-exclusive@example.com';
```

---

### Шаг 5: Запустить проект 🎉

```bash
npm run dev
```

Перейти на: `http://localhost:3000/cabinet/release-basic/create`

---

## ✅ Проверочный список

- [ ] SQL миграция выполнена
- [ ] 4 Storage бакета созданы
- [ ] RLS политики настроены
- [ ] Переменные окружения установлены
- [ ] Тестовые пользователи с ролями созданы
- [ ] Проект запущен
- [ ] Страница создания релиза открывается

---

## 🧪 Тестовые сценарии

### Basic пользователь:
1. Выбрать тип "Сингл" → добавить 1 трек → загрузить WAV
2. Заполнить все поля → дойти до оплаты
3. Увидеть калькулятор: **500 ₽**
4. Скопировать реквизиты
5. Загрузить скриншот чека
6. Отправить на модерацию

### Exclusive пользователь:
1. Выбрать тип "Альбом" → добавить 10 треков
2. Заполнить поля → НЕ видеть шаг оплаты
3. Сразу попасть на финальную отправку
4. Отправить без чека

---

## 🐛 Частые проблемы

**Проблема**: "Файл не загружается"  
**Решение**: Проверить что бакет создан и RLS политики настроены

**Проблема**: "Роль не определяется"  
**Решение**: Убедиться что в таблице `profiles` есть колонка `role`

**Проблема**: "Калькулятор не показывается"  
**Решение**: Проверить что `userRole === 'basic'` и треки добавлены

---

## 📚 Документация

- 📖 **Полный отчет**: `RELEASE_WIZARD_IMPLEMENTATION_REPORT.md`
- 📖 **Storage настройка**: `docs/SUPABASE_STORAGE_SETUP.md`
- 📖 **План этапов**: `RELEASE_WIZARD_PLAN.md`

---

**Готово! Wizard работает! 🎵**
