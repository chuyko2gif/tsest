# 📋 Система создания задач (Tasks Wizard)

## Обзор
Система Tasks Wizard предназначена для создания и управления задачами для релизов, аналогичная Release Wizard, но для задач.

## Архитектура

### 1. Основные компоненты

#### TaskWizardPage (`app/cabinet/tasks/create/page.tsx`)
Главная страница создания задачи с пошаговым процессом:
- Тип задачи (баг, фича, улучшение)
- Детали задачи
- Приоритет и срок
- Назначение исполнителя
- Вложения
- Подтверждение

#### Шаги создания задачи

1. **TaskTypeStep** - Выбор типа задачи
   - 🐛 Баг (исправление ошибки)
   - ✨ Фича (новая функциональность)
   - 🔧 Улучшение (оптимизация существующего)
   - 📝 Документация

2. **TaskDetailsStep** - Детали задачи
   - Название задачи (обязательно)
   - Подробное описание
   - Связанные модули/компоненты
   - Теги

3. **PriorityStep** - Приоритет и срок
   - 🔴 Критичный (требует немедленного решения)
   - 🟠 Высокий (важная задача)
   - 🟡 Средний (плановая задача)
   - 🟢 Низкий (когда будет время)
   - Срок выполнения (опционально)

4. **AssignmentStep** - Назначение
   - Исполнитель (выбор из команды)
   - Наблюдатели
   - Связанные задачи

5. **AttachmentsStep** - Вложения
   - Скриншоты
   - Логи
   - Документы
   - Ссылки

6. **ConfirmationStep** - Проверка и отправка
   - Просмотр всех данных
   - Создание задачи

## Структура базы данных

```sql
-- Создание таблицы задач
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Основная информация
  title TEXT NOT NULL,
  description TEXT,
  type TEXT NOT NULL CHECK (type IN ('bug', 'feature', 'improvement', 'documentation')),
  status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'review', 'done', 'closed')),
  priority TEXT NOT NULL CHECK (priority IN ('critical', 'high', 'medium', 'low')),
  
  -- Связи
  creator_id UUID REFERENCES auth.users(id),
  assignee_id UUID REFERENCES auth.users(id),
  related_release_id UUID REFERENCES releases(id),
  
  -- Метаданные
  tags TEXT[],
  components TEXT[],
  due_date TIMESTAMP WITH TIME ZONE,
  
  -- Вложения
  attachments JSONB DEFAULT '[]'::jsonb,
  
  -- Дополнительно
  estimated_hours INTEGER,
  actual_hours INTEGER,
  
  CONSTRAINT valid_estimated_hours CHECK (estimated_hours >= 0),
  CONSTRAINT valid_actual_hours CHECK (actual_hours >= 0)
);

-- Индексы для оптимизации
CREATE INDEX idx_tasks_creator ON tasks(creator_id);
CREATE INDEX idx_tasks_assignee ON tasks(assignee_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_priority ON tasks(priority);
CREATE INDEX idx_tasks_type ON tasks(type);
CREATE INDEX idx_tasks_created_at ON tasks(created_at DESC);

-- Комментарии к задачам
CREATE TABLE task_comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id),
  comment TEXT NOT NULL,
  attachments JSONB DEFAULT '[]'::jsonb
);

-- История изменений задач
CREATE TABLE task_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id),
  field TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT
);
```

## Файловая структура

```
app/cabinet/tasks/
├── page.tsx                          # Список задач
├── create/
│   ├── page.tsx                      # Главная страница создания
│   └── components/
│       ├── index.ts
│       ├── TaskTypeSelector.tsx      # Выбор типа задачи
│       ├── TaskDetailsStep.tsx       # Детали задачи
│       ├── PriorityStep.tsx          # Приоритет и срок
│       ├── AssignmentStep.tsx        # Назначение
│       ├── AttachmentsStep.tsx       # Вложения
│       └── ConfirmationStep.tsx      # Подтверждение
├── [id]/
│   ├── page.tsx                      # Просмотр задачи
│   └── edit/
│       └── page.tsx                  # Редактирование
└── components/
    ├── TaskCard.tsx                  # Карточка задачи
    ├── TaskFilters.tsx               # Фильтры
    ├── TaskKanban.tsx                # Канбан доска
    └── TaskList.tsx                  # Список задач
```

## API Endpoints

```typescript
// app/api/tasks/create/route.ts
POST /api/tasks/create
Body: {
  title: string;
  description: string;
  type: 'bug' | 'feature' | 'improvement' | 'documentation';
  priority: 'critical' | 'high' | 'medium' | 'low';
  assignee_id?: string;
  tags?: string[];
  components?: string[];
  due_date?: string;
  attachments?: Array<{ name: string; url: string; type: string }>;
}

// app/api/tasks/[id]/route.ts
GET /api/tasks/[id]
PUT /api/tasks/[id]
DELETE /api/tasks/[id]

// app/api/tasks/route.ts
GET /api/tasks?status=open&priority=high&assignee=user_id
```

## Функционал

### Создание задачи
1. Пользователь выбирает тип задачи
2. Заполняет детали
3. Устанавливает приоритет
4. Назначает исполнителя (опционально)
5. Добавляет вложения (опционально)
6. Подтверждает создание

### Управление задачами
- Просмотр списка всех задач
- Фильтрация по статусу, приоритету, типу
- Канбан доска для визуализации
- Поиск по названию и описанию
- Массовые операции

### Работа с задачей
- Просмотр деталей
- Редактирование
- Изменение статуса
- Добавление комментариев
- Прикрепление файлов
- Отслеживание времени
- История изменений

## UI/UX принципы

### Визуальные индикаторы
- 🐛 Красный - Баги
- ✨ Синий - Фичи
- 🔧 Желтый - Улучшения
- 📝 Серый - Документация

### Приоритеты
- 🔴 Критичный - Красный пульсирующий
- 🟠 Высокий - Оранжевый
- 🟡 Средний - Желтый
- 🟢 Низкий - Зеленый

### Статусы
- 📝 Open - Открыто
- 🔄 In Progress - В работе
- 👀 Review - На проверке
- ✅ Done - Выполнено
- ❌ Closed - Закрыто

## Интеграция с Release Wizard

### Связь задач с релизами
- Автоматическое создание задач при создании релиза
- Связывание задач с конкретными релизами
- Отслеживание прогресса релиза через задачи
- Блокировка релиза при наличии критичных задач

### Типовые задачи для релиза
1. "Проверка обложки релиза"
2. "Модерация треков"
3. "Проверка метаданных"
4. "Верификация контракта"
5. "Публикация на площадках"

## Уведомления

### Email уведомления
- Создание новой задачи
- Назначение на вас
- Изменение статуса
- Новый комментарий
- Приближение дедлайна

### In-app уведомления
- Реал-тайм обновления через Supabase Realtime
- Звуковые уведомления для критичных задач
- Бейджи с количеством непрочитанных

## Аналитика

### Метрики
- Среднее время выполнения задачи
- Количество задач по статусам
- Загрузка исполнителей
- Тренды по типам задач
- Просроченные задачи

### Отчеты
- Еженедельный отчет по задачам
- Месячная статистика
- Отчет по релизам
- Персональная производительность

## Доступ и права

### Роли
- **Admin** - Полный доступ ко всем задачам
- **Manager** - Создание и назначение задач
- **Developer** - Работа с назначенными задачами
- **User** - Просмотр своих задач

### Permissions
```typescript
const canCreateTask = (userRole: string) => {
  return ['admin', 'manager'].includes(userRole);
};

const canEditTask = (userRole: string, taskCreatorId: string, userId: string) => {
  return userRole === 'admin' || taskCreatorId === userId;
};

const canDeleteTask = (userRole: string) => {
  return userRole === 'admin';
};
```

## Следующие шаги

1. ✅ Создать структуру базы данных
2. ✅ Разработать UI компоненты
3. ⏳ Реализовать API endpoints
4. ⏳ Добавить систему уведомлений
5. ⏳ Интегрировать с Release Wizard
6. ⏳ Добавить аналитику
7. ⏳ Написать тесты

## Пример использования

```typescript
// Создание задачи для релиза
const createReleaseTask = async (releaseId: string) => {
  const task = await fetch('/api/tasks/create', {
    method: 'POST',
    body: JSON.stringify({
      title: `Проверка релиза #${releaseId}`,
      description: 'Проверить все материалы релиза перед публикацией',
      type: 'feature',
      priority: 'high',
      related_release_id: releaseId,
      tags: ['release', 'moderation'],
      components: ['releases', 'admin']
    })
  });
  
  return task;
};
```
