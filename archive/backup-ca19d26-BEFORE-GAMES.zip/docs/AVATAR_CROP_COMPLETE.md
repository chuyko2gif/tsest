# Реализация кадрирования аватара с эффектом скролла

## ✅ Выполнено

Все задачи из чек-листа успешно реализованы!

### 1. Кадрирование аватара
- ✅ Установлена библиотека `react-easy-crop`
- ✅ Создан компонент `AvatarCropModal.tsx` с полным функционалом кадрирования
- ✅ Форма рамки: квадрат со скругленными углами
- ✅ Управление зумом с визуальным слайдером
- ✅ Сохранение обрезанного изображения в формате JPEG

### 2. Эффект медленного скролла
- ✅ Создан специализированный хук `useAvatarScrollEffect.ts`
- ✅ Реализовано медленное "отрезание" аватара при скролле
- ✅ Плавная анимация с использованием `clip-path` и `transform`
- ✅ Оптимизация производительности через `requestAnimationFrame`

### 3. Поддержка мобильных устройств
- ✅ Реализована обработка touch событий (`touchstart`, `touchmove`)
- ✅ Passive event listeners для производительности
- ✅ Адаптивная работа на всех размерах экранов
- ✅ Автоматическое определение touch-устройств

## 📁 Созданные/Измененные файлы

### Новые файлы:
1. **`app/cabinet/components/modals/AvatarCropModal.tsx`**
   - Компонент модального окна с кадрированием
   - Интерфейс с react-easy-crop
   - Контроль зума и позиционирования

2. **`app/cabinet/hooks/useScrollEffect.ts`**
   - Универсальный хук для эффектов скролла
   - Поддержка desktop и mobile
   - Функции `getClipPathStyle` и `getFadeStyle`

3. **`app/cabinet/hooks/useAvatarScrollEffect.ts`**
   - Специализированный хук для аватара
   - Очень медленный эффект отрезания
   - Оптимизированная производительность

4. **`AVATAR_CROP_IMPLEMENTATION.md`**
   - Подробный план задач
   - Технические детали
   - Чек-лист выполнения

### Обновленные файлы:
1. **`app/cabinet/page.tsx`**
   - Интеграция AvatarCropModal
   - Обработка сохранения кадрированного изображения
   - Упрощенная логика загрузки

2. **`app/cabinet/components/sidebar/ProfileSidebar.tsx`**
   - Добавлен эффект медленного скролла для аватара
   - Плавная анимация при прокрутке страницы

3. **`app/cabinet/components/modals/index.ts`**
   - Экспорт нового компонента AvatarCropModal

## 🎨 Особенности реализации

### Кадрирование
```typescript
// Квадратная рамка со скругленными углами
<Cropper
  image={imageSrc}
  crop={crop}
  zoom={zoom}
  aspect={1}  // Соотношение сторон 1:1
  cropShape="rect"
  style={{
    cropAreaStyle: {
      borderRadius: '1rem',
    },
  }}
/>
```

### Эффект скролла
```typescript
// Очень медленное отрезание
progress = Math.pow(progress, 2) * 0.3;

// Параметры анимации
clipPath: `inset(${clipPercentage}% 0 0 0)`,  // Обрезание сверху
translateY: progress * 15,                      // Смещение до 15px
opacity: Math.max(1 - progress * 1.5, 0.7)     // Минимум 70% прозрачности
```

### Touch поддержка
```typescript
// Автоматическое определение touch устройств
if ('ontouchstart' in window) {
  document.addEventListener('touchstart', handleTouchStart, { passive: true });
  document.addEventListener('touchmove', handleTouchMove, { passive: true });
}
```

## 🚀 Как использовать

### Кадрирование аватара:
1. Откройте кабинет пользователя
2. Нажмите на аватар или на кнопку "Изменить"
3. Выберите изображение (до 5 MB)
4. Используйте перетаскивание для позиционирования
5. Используйте слайдер для масштабирования (1x - 3x)
6. Нажмите "Применить"

### Эффект скролла:
- Просто прокрутите страницу вниз
- Аватар будет медленно "отрезаться" сверху
- Работает как на desktop (колесико мыши), так и на mobile (свайп)

## ⚡ Оптимизация производительности

1. **RequestAnimationFrame**: Плавная анимация без лагов
2. **Passive listeners**: Быстрая обработка событий скролла
3. **willChange**: Оптимизация GPU рендеринга
4. **Debouncing**: Предотвращение избыточных вычислений

## 🎯 Технические детали

### Библиотеки:
- `react-easy-crop`: ^5.0.8
- Встроенные React хуки: `useState`, `useEffect`, `useRef`, `useCallback`

### Форматы:
- Входные изображения: любые (image/*)
- Выходной формат: JPEG (качество 95%)
- Максимальный размер: 5 MB

### Совместимость:
- ✅ Chrome
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ iOS Safari
- ✅ Android Chrome

## 📱 Мобильная оптимизация

1. **Touch события**: Нативная поддержка свайпов
2. **Адаптивный UI**: Модальное окно адаптируется под размер экрана
3. **Производительность**: Passive listeners для 60fps
4. **Жесты**: Поддержка pinch-to-zoom в компоненте кадрирования

## 🐛 Известные особенности

1. Эффект скролла работает только когда аватар виден на экране
2. Максимальное "отрезание" - 30% от высоты аватара
3. На очень медленных устройствах может быть небольшая задержка

## 📝 Примеры использования

### Использование хука в другом компоненте:
```typescript
import { useAvatarScrollEffect } from '@/app/cabinet/hooks/useAvatarScrollEffect';

function MyComponent() {
  const { avatarRef, transform } = useAvatarScrollEffect();
  
  return (
    <div
      ref={avatarRef}
      style={{
        clipPath: transform.clipPath,
        transform: `translateY(${transform.translateY}px)`,
        opacity: transform.opacity,
      }}
    >
      Контент
    </div>
  );
}
```

### Использование универсального хука:
```typescript
import { useScrollEffect, getClipPathStyle } from '@/app/cabinet/hooks/useScrollEffect';

function MyComponent() {
  const { elementRef, scrollProgress } = useScrollEffect({ speed: 0.5 });
  const style = getClipPathStyle(scrollProgress, 'bottom');
  
  return <div ref={elementRef} style={style}>Контент</div>;
}
```

## ✨ Дополнительные возможности

Хуки могут быть использованы для других элементов:
- Карточки релизов
- Новости
- Блоки контента
- Изображения в галерее

Просто импортируйте хук и применяйте к любому элементу!
