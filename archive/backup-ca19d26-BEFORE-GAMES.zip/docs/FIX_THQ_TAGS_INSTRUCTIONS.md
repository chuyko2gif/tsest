# 🚨 ИНСТРУКЦИЯ ПО ВОССТАНОВЛЕНИЮ ТЕГОВ THQ

## 📋 Что произошло

Ошибочно заменили все теги участников с **THQ-** на **thq-** в:
- ✅ База данных (member_id в таблице profiles)
- ✅ Функции генерации новых ID
- ✅ Код на сайте (frontend)

## 🔧 Что было исправлено

### 1. База данных
- ✅ Создан скрипт восстановления: `sql/FIX_THQ_TAGS_RESTORE.sql`
- ✅ Исправлен файл: `sql/ADMIN_ROLE_MANAGEMENT.sql`
- ✅ Исправлены все вспомогательные скрипты

### 2. Код проекта
- ✅ `app/cabinet/page.tsx` - исправлена генерация member_id
- ✅ `app/admin/components/UsersTab.tsx` - исправлено отображение

### 3. SQL скрипты
- ✅ `sql/fix_profile_trigger.sql`
- ✅ `sql/fix_registration_without_email_confirmation.sql`
- ✅ `sql/FIX_TRIGGER.sql`
- ✅ `sql/add_email_to_profiles.sql`
- ✅ `sql/create_profiles.sql`

## 📝 ПОРЯДОК ДЕЙСТВИЙ

### ШАГ 1: Применить SQL скрипт

1. Откройте Supabase Dashboard
2. Перейдите в **SQL Editor**
3. Откройте файл `sql/FIX_THQ_TAGS_RESTORE.sql`
4. Скопируйте весь код и вставьте в SQL Editor
5. Нажмите **RUN** или **F5**

**Что сделает скрипт:**
- 📊 Покажет диагностику текущего состояния
- 💾 Создаст резервную копию в поле `member_id_backup`
- 🔧 Заменит все `thq-` на `THQ-` в таблице profiles
- 🔄 Обновит функцию генерации для новых пользователей
- 🚪 Удалит все сессии (пользователи выйдут из системы)
- ✅ Покажет финальную статистику

### ШАГ 2: Перезапустить сервер Next.js

```powershell
# Остановите текущий сервер (Ctrl+C)

# Перезапустите проект
npm run dev
```

### ШАГ 3: Инструкция для пользователей

**Все пользователи должны:**

1. **Выйти из аккаунта**
   - Нажать на кнопку выхода

2. **Войти заново**
   - Использовать свои credentials
   - После входа теги будут правильными: **THQ-XXXX**

3. **Если теги всё ещё неправильные:**
   
   **Вариант А: Очистка кеша браузера**
   - Нажмите `Ctrl + Shift + Delete`
   - Выберите "Кеш" и "Cookies"
   - Очистите
   - Обновите страницу (`F5`)
   
   **Вариант Б: Через консоль браузера**
   - Нажмите `F12` (открыть DevTools)
   - Перейдите во вкладку **Console**
   - Вставьте код:
   ```javascript
   localStorage.clear();
   sessionStorage.clear();
   location.reload();
   ```
   - Нажмите `Enter`

## ✅ Проверка результата

### В базе данных (Supabase)
```sql
-- Проверить что все теги исправлены
SELECT 
  member_id,
  nickname,
  email,
  role
FROM public.profiles
ORDER BY created_at DESC
LIMIT 20;

-- Все member_id должны начинаться с THQ- (заглавными буквами)
```

### На сайте

1. Войдите в личный кабинет
2. Проверьте свой member_id в профиле
3. Должно быть: **THQ-XXXX** (с заглавными буквами)

## 🔍 Если что-то пошло не так

### Проблема: В базе теги правильные, но на сайте неправильные

**Решение:**
```sql
-- Удалите все сессии (выкинет всех пользователей)
TRUNCATE TABLE auth.sessions RESTART IDENTITY CASCADE;
```

Затем все должны перезайти.

### Проблема: Теги в базе всё ещё thq-

**Решение:**
```sql
-- Принудительное исправление
UPDATE public.profiles
SET member_id = REPLACE(member_id, 'thq-', 'THQ-')
WHERE member_id LIKE 'thq-%';

-- Проверка
SELECT COUNT(*) as fixed_count
FROM public.profiles
WHERE member_id LIKE 'THQ-%';
```

### Проблема: Новые пользователи получают thq- вместо THQ-

**Решение:**
```sql
-- Пересоздать функцию с правильным форматом
DROP FUNCTION IF EXISTS public.generate_member_id();

CREATE OR REPLACE FUNCTION public.generate_member_id()
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
  new_member_id TEXT;
  id_exists BOOLEAN;
BEGIN
  LOOP
    new_member_id := 'THQ-' || LPAD(FLOOR(1000 + RANDOM() * 9000)::TEXT, 4, '0');
    
    SELECT EXISTS(
      SELECT 1 FROM public.profiles WHERE member_id = new_member_id
    ) INTO id_exists;
    
    EXIT WHEN NOT id_exists;
  END LOOP;
  
  RETURN new_member_id;
END;
$$;
```

## 📊 Финальная проверка

Выполните в Supabase:

```sql
-- Статистика
SELECT 
  COUNT(*) as total_users,
  COUNT(CASE WHEN member_id LIKE 'THQ-%' THEN 1 END) as correct_tags,
  COUNT(CASE WHEN member_id LIKE 'thq-%' THEN 1 END) as incorrect_tags
FROM public.profiles;

-- Результат должен быть:
-- correct_tags = total_users
-- incorrect_tags = 0
```

## 🎯 Итог

После выполнения всех шагов:

- ✅ Все существующие пользователи имеют теги **THQ-XXXX**
- ✅ Новые пользователи получают теги **THQ-XXXX**
- ✅ На сайте отображаются правильные теги
- ✅ В базе данных всё правильно

## 📞 Поддержка

Если возникли проблемы:
1. Проверьте логи Next.js сервера
2. Проверьте консоль браузера (F12)
3. Проверьте данные в Supabase SQL Editor

---

**Дата исправления:** 26.12.2025
**Статус:** ✅ Готово к применению
