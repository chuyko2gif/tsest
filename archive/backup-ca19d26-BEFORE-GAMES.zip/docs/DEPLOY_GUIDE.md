# Инструкция по деплою на тестовый хост

## 🚀 Быстрый деплой на Vercel (Рекомендуется)

### Шаг 1: Подготовка проекта

1. **Проверьте файлы окружения:**
   - Убедитесь что у вас есть `.env.example` с примерами переменных
   - В продакшене эти переменные будут настроены через Vercel Dashboard

2. **Создайте `.gitignore` (если нет):**
```
node_modules/
.next/
.env.local
.env
.vercel
```

### Шаг 2: Настройка Git и GitHub

```powershell
# Инициализация Git (если еще не сделано)
git init

# Добавьте все файлы
git add .

# Сделайте коммит
git commit -m "Initial commit for deployment"

# Создайте репозиторий на GitHub и залейте код
# (замените YOUR_USERNAME и YOUR_REPO на свои)
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

### Шаг 3: Деплой на Vercel

1. **Зайдите на https://vercel.com**
2. **Войдите через GitHub**
3. **Нажмите "Add New Project"**
4. **Выберите ваш репозиторий**
5. **Настройте переменные окружения:**
   - `NEXT_PUBLIC_SUPABASE_URL` - ваш Supabase URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` - публичный ключ Supabase
   - `SUPABASE_SERVICE_ROLE_KEY` - секретный ключ (если используется)
   - `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS` - если используется email
   - Любые другие переменные из вашего `.env.local`

6. **Нажмите "Deploy"**

### Шаг 4: После деплоя

- Vercel автоматически создаст тестовый URL вида: `your-project.vercel.app`
- При каждом push в GitHub будет автоматический редеплой
- Можете настроить кастомный домен в настройках Vercel

---

## 🔧 Альтернативные варианты

### Вариант 2: Netlify

1. Зайдите на https://netlify.com
2. Подключите GitHub репозиторий
3. Build command: `npm run build`
4. Publish directory: `.next`
5. Добавьте переменные окружения

### Вариант 3: Railway

1. Зайдите на https://railway.app
2. Создайте новый проект из GitHub
3. Railway автоматически определит Next.js
4. Добавьте переменные окружения
5. Деплой происходит автоматически

### Вариант 4: Render

1. Зайдите на https://render.com
2. Создайте новый Web Service
3. Подключите GitHub
4. Build Command: `npm install && npm run build`
5. Start Command: `npm start`

---

## ⚙️ Важные моменты

### Переменные окружения

Создайте файл `.env.example` с примерами всех нужных переменных:

```env
NEXT_PUBLIC_SUPABASE_URL=your-supabase-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### Проверка перед деплоем

```powershell
# Проверьте что проект собирается локально
npm run build

# Проверьте что продакшн версия работает
npm start
```

### База данных Supabase

- Убедитесь что в Supabase настроены правильные политики безопасности (RLS)
- Проверьте что URL в настройках Supabase доступен публично
- Добавьте домен Vercel в список разрешенных URL в Supabase

---

## 📝 Чеклист перед деплоем

- [ ] Проект собирается без ошибок (`npm run build`)
- [ ] Все переменные окружения задокументированы
- [ ] `.gitignore` настроен правильно (не коммитим `.env`, `node_modules`)
- [ ] Supabase база данных настроена и доступна
- [ ] Email-сервис настроен (если используется)
- [ ] Все секретные ключи готовы для добавления в Vercel

---

## 🆘 Решение проблем

### Ошибка при сборке
- Проверьте логи в Vercel Dashboard
- Убедитесь что все зависимости в `package.json`
- Проверьте версию Node.js (Vercel использует последнюю LTS)

### Ошибки подключения к базе
- Проверьте переменные окружения в Vercel
- Убедитесь что Supabase URL правильный
- Проверьте RLS политики в Supabase

### Email не отправляется
- Проверьте SMTP настройки в переменных окружения
- Убедитесь что используете App Password для Gmail
- Проверьте логи функций в Vercel

---

## 🔗 Полезные ссылки

- [Vercel Documentation](https://vercel.com/docs)
- [Next.js Deployment](https://nextjs.org/docs/deployment)
- [Supabase + Vercel](https://supabase.com/docs/guides/getting-started/tutorials/with-nextjs)
