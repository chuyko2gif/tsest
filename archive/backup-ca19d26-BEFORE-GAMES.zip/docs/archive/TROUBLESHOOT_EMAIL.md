# 🔍 Диагностика проблемы с email

## 1. ⚙️ Проверьте настройки в Supabase Dashboard:

### Authentication → Providers → Email:
- ✅ **Enable Email provider** - должно быть включено
- ✅ **Confirm email** - должно быть ВКЛЮЧЕНО
- ✅ **Secure email change** - можно выключить
- Нажмите **Save**

### Settings → Auth → SMTP Settings:
Убедитесь что:
```
✅ Enable Custom SMTP - ВКЛЮЧЕНО
Host: smtp-relay.brevo.com
Port: 587
Username: maksbroska@gmail.com
Password: xsmtpsib-426123...
Sender email: littlehikai@gmail.com
Sender name: thqlabel
✅ Enable STARTTLS - ВКЛЮЧЕНО
```

## 2. 📋 Проверьте логи в Supabase:

1. Откройте **Logs** → **Auth Logs** (в левом меню)
2. Найдите последнюю запись о регистрации
3. Проверьте есть ли ошибки отправки email

Частые ошибки:
- `smtp connection failed` - неверные данные SMTP
- `authentication failed` - неверный пароль/ключ
- `sender rejected` - неверный sender email

## 3. 🧪 Тест отправки вручную:

В Supabase SQL Editor выполните:
```sql
SELECT 
  id, 
  email, 
  email_confirmed_at, 
  confirmed_at,
  created_at
FROM auth.users 
ORDER BY created_at DESC 
LIMIT 5;
```

Если `email_confirmed_at` = NULL - значит email не подтверждён.

## 4. ✉️ Проверьте Brevo:

1. Войдите в [app.brevo.com](https://app.brevo.com)
2. Перейдите в **Campaigns** → **Transactional**
3. Проверьте список отправленных писем
4. Если там пусто - значит Supabase не отправляет через Brevo

## 5. 🔄 Пересоздайте пользователя:

Удалите тестового пользователя и создайте заново:
```sql
-- В Supabase SQL Editor:
DELETE FROM auth.users WHERE email = 'ваш_email@test.com';
DELETE FROM profiles WHERE email = 'ваш_email@test.com';
```

Затем зарегистрируйтесь заново.

## 6. ⚠️ Временное решение - отключите подтверждение:

Если нужно срочно:
1. **Authentication** → **Providers** → **Email**
2. **ВЫКЛЮЧИТЕ** "Confirm email"
3. Сохраните

Тогда пользователи смогут входить сразу без подтверждения.

## 7. 📧 Проверьте папку "Спам":

Первые письма от Brevo часто попадают в спам!
