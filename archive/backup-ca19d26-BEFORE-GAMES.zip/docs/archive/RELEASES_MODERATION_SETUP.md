# 📦 Настройка системы модерации релизов

## 📋 Обзор

Система позволяет:
- Пользователям с ролью **Exclusive** — отправлять релизы на модерацию бесплатно
- Пользователям с ролью **Basic** — отправлять релизы на модерацию с оплатой 500₽
- Админам/Владельцам — просматривать все релизы, проверять оплату, утверждать или отклонять релизы

## 🗄️ Шаг 1: Настройка базы данных

### 1.1 Обновление таблицы releases

Выполните SQL скрипт в Supabase SQL Editor:

```bash
sql/update_releases_for_moderation.sql
```

Этот скрипт:
- Добавит новые поля в таблицу `releases`:
  - `user_role` — роль пользователя ('basic' или 'exclusive')
  - `payment_status` — статус оплаты для Basic ('pending', 'verified', 'rejected')
  - `payment_receipt_url` — ссылка на чек оплаты
  - `payment_amount` — сумма оплаты
  - `rejection_reason` — причина отклонения релиза
  - `moderated_by` — ID админа, который модерировал
  - `moderated_at` — дата модерации
- Создаст SQL функции:
  - `get_pending_releases()` — получение релизов на модерации
  - `approve_release(release_id, admin_id)` — утверждение релиза
  - `reject_release(release_id, admin_id, reason)` — отклонение релиза
  - `verify_payment(release_id, admin_id)` — подтверждение оплаты
- Создаст индексы для оптимизации
- Обновит RLS политики для доступа админов

### 1.2 Создание Storage Buckets

Выполните SQL скрипт:

```bash
sql/CREATE_STORAGE_BUCKETS.sql
```

Или создайте вручную через Supabase Dashboard → Storage:

1. **release-covers** (публичный)
   - Для обложек релизов
   - Лимит: 10MB
   - Типы: image/jpeg, image/png, image/gif, image/webp

2. **payment-receipts** (публичный, но с RLS)
   - Для чеков оплаты
   - Лимит: 5MB
   - Типы: image/jpeg, image/png, image/gif, image/webp
   - Доступ: только админы и владелец чека

## ✅ Шаг 2: Проверка настройки

### 2.1 Проверка таблицы

```sql
-- Проверка структуры таблицы
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'releases';

-- Проверка функций
SELECT routine_name 
FROM information_schema.routines 
WHERE routine_type = 'FUNCTION' 
AND routine_schema = 'public'
AND routine_name IN ('get_pending_releases', 'approve_release', 'reject_release', 'verify_payment');
```

### 2.2 Проверка Storage

```sql
-- Проверка buckets
SELECT id, name, public 
FROM storage.buckets 
WHERE id IN ('release-covers', 'payment-receipts');
```

## 🎨 Шаг 3: Использование системы

### Для пользователей Exclusive

1. Кабинет → Релизы → Добавить релиз
2. Заполнить 7 шагов формы
3. Нажать "Отправить на модерацию"
4. Релиз попадает в админ панель со статусом "На модерации"

### Для пользователей Basic

1. Кабинет → Релизы → Добавить релиз
2. Откроется форма оплаты с реквизитами:
   - Сумма: 500₽
   - Карта: 2200 7007 1234 5678
   - СБП: +7 900 123 45 67
   - Получатель: THQ LABEL
3. После оплаты загрузить чек
4. Заполнить форму релиза
5. Отправить на модерацию
6. Админ сначала проверит оплату, затем утвердит/отклонит релиз

### Для админов/владельцев

1. Админ панель → Релизы
2. Просмотр всех релизов с фильтрами по статусу
3. Клик на релиз — открывается модальное окно с полной информацией:
   - Обложка, название, артист
   - Роль пользователя (Basic/Exclusive)
   - Статус оплаты (для Basic)
   - Чек оплаты (для Basic)
   - Список треков
   - Платформы распространения
   - Описание
4. Действия модерации:
   - **Для Basic**: сначала "Подтвердить оплату", затем "Утвердить релиз"
   - **Для Exclusive**: сразу "Утвердить релиз"
   - Или "Отклонить релиз" с указанием причины

## 📊 Структура данных

### Таблица releases

```typescript
interface Release {
  id: string;
  user_id: string;
  user_role: 'basic' | 'exclusive';
  title: string;
  artist_name: string;
  cover_url: string;
  genre: string;
  subgenres: string[];
  release_date: string;
  tracks: Array<{
    title: string;
    link: string;
    hasDrugs: boolean;
    lyrics: string;
    language: string;
  }>;
  platforms: string[];
  countries: string[];
  collaborators: string[];
  focus_track: string;
  album_description: string;
  status: 'draft' | 'pending' | 'distributed' | 'rejected';
  payment_status: 'pending' | 'verified' | 'rejected' | null;
  payment_receipt_url: string | null;
  payment_amount: number | null;
  rejection_reason: string | null;
  contract_agreed: boolean;
  contract_agreed_at: string | null;
  moderated_by: string | null;
  moderated_at: string | null;
  created_at: string;
  updated_at: string;
}
```

## 🔐 Безопасность (RLS)

Политики доступа:
- Пользователи видят только свои релизы
- Админы/владельцы видят все релизы
- Пользователи Basic могут загружать чеки только в свою папку
- Админы могут просматривать все чеки

## 🚀 Готово!

После выполнения всех шагов:
1. Exclusive пользователи могут отправлять релизы бесплатно
2. Basic пользователи сначала оплачивают 500₽ и загружают чек
3. Админы модерируют все релизы в единой панели
4. Система автоматически отслеживает статусы оплаты и модерации

## 📝 Примечания

- Чеки оплаты хранятся в папке `payment-receipts/{user_id}/{timestamp}.jpg`
- Обложки релизов в папке `release-covers/{user_id}/{timestamp}.jpg`
- При отклонении релиза обязательно указывайте причину
- Basic релизы можно утвердить только после подтверждения оплаты
