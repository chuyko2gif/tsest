# 🔧 ПОЛНОЕ ИСПРАВЛЕНИЕ ПРОБЛЕМЫ С ПОВТОРНОЙ РЕГИСТРАЦИЕЙ

## Проблема
Вы удаляете пользователя из `profiles`, но он остается в `auth.users`. При повторной попытке регистрации с тем же email **письмо не приходит**.

## Решение в 2 шага

### Шаг 1: Выполнить SQL (ОБЯЗАТЕЛЬНО!)

Откройте **Supabase Dashboard** → **SQL Editor** и выполните:

```sql
-- ИСПРАВЛЕНИЕ КАСКАДНОГО УДАЛЕНИЯ В ОБЕ СТОРОНЫ

-- 1. Функция для удаления из auth.users при удалении из profiles
CREATE OR REPLACE FUNCTION delete_auth_user_on_profile_delete()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  DELETE FROM auth.users WHERE id = OLD.id;
  RETURN OLD;
END;
$$;

-- 2. Создаем триггер
DROP TRIGGER IF EXISTS on_profile_delete_cascade_to_auth ON profiles;

CREATE TRIGGER on_profile_delete_cascade_to_auth
  BEFORE DELETE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION delete_auth_user_on_profile_delete();

-- 3. Убедимся что в обратную сторону тоже работает
ALTER TABLE profiles 
  DROP CONSTRAINT IF EXISTS profiles_id_fkey,
  ADD CONSTRAINT profiles_id_fkey 
    FOREIGN KEY (id) 
    REFERENCES auth.users(id) 
    ON DELETE CASCADE;
```

### Шаг 2: Очистить существующие "мертвые" аккаунты

Если у вас уже есть пользователи в `auth.users` без записи в `profiles`:

```sql
-- Найти "мертвые" аккаунты (есть в auth.users, но нет в profiles)
SELECT u.id, u.email, u.created_at
FROM auth.users u
LEFT JOIN profiles p ON u.id = p.id
WHERE p.id IS NULL;

-- УДАЛИТЬ их (если нашлись)
DELETE FROM auth.users
WHERE id IN (
  SELECT u.id
  FROM auth.users u
  LEFT JOIN profiles p ON u.id = p.id
  WHERE p.id IS NULL
);
```

## Как это работает

### ДО исправления:
```
Админ удаляет из profiles → auth.users остается ❌
Пользователь пытается зарегистрироваться → "Email уже существует" ❌
Письмо не приходит ❌
```

### ПОСЛЕ исправления:
```
Админ удаляет из profiles → auth.users тоже удаляется ✅
Email полностью свободен ✅
Пользователь регистрируется → Письмо приходит ✅
```

## Проверка что все работает

1. **Создайте тестового пользователя:**
   - Зарегистрируйтесь с email `test@example.com`
   - Подтвердите email

2. **Удалите его из админки** (или через SQL):
   ```sql
   DELETE FROM profiles WHERE email = 'test@example.com';
   ```

3. **Проверьте что он удалился из auth.users:**
   ```sql
   SELECT * FROM auth.users WHERE email = 'test@example.com';
   -- Должно вернуть 0 строк
   ```

4. **Попробуйте зарегистрироваться снова** с `test@example.com`:
   - Письмо должно прийти ✅
   - Никаких ошибок ✅

## Дополнительно: Код также исправлен

Если триггер не сработал или есть задержка, код в [app/auth/page.tsx](../app/auth/page.tsx) теперь автоматически отправляет письмо повторно при ошибке "User already registered".

## Итог

После выполнения SQL:
- ✅ При удалении из `profiles` автоматически удаляется из `auth.users`
- ✅ При удалении из `auth.users` автоматически удаляется из `profiles`
- ✅ Email и nickname полностью освобождаются
- ✅ Повторная регистрация работает корректно
- ✅ Письма приходят всегда
