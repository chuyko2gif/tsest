# Новая финансовая система с транзакциями

## 📋 Что изменилось

### 1. Таблица транзакций (`transactions`)
Теперь каждая финансовая операция записывается в отдельную таблицу с:
- **Уникальным UUID** - невозможно дублирование
- **Балансом до и после** - полный аудит
- **Связью с операцией** - ссылка на payout или withdrawal
- **Статусом** - pending, completed, cancelled, failed
- **Историей отмены** - кто, когда и почему отменил

### 2. Функции PostgreSQL

#### `create_transaction()`
Создает транзакцию атомарно:
- Блокирует строку профиля (FOR UPDATE)
- Проверяет достаточность средств
- Создает запись транзакции
- Обновляет баланс
- Все в одной транзакции БД

#### `cancel_transaction()`
Отменяет транзакцию с проверками:
- ❌ Нельзя отменить если были выводы после
- ❌ Нельзя отменить уже отмененную
- ✓ Создает обратную транзакцию автоматически
- ✓ Сохраняет причину и автора отмены

## 🚀 Порядок внедрения

### Шаг 1: Создать таблицу транзакций
```sql
-- Выполнить в Supabase SQL Editor:
\i sql/create_transactions_table.sql
```

### Шаг 2: Обнулить все балансы (ОПЦИОНАЛЬНО)
⚠️ **ВНИМАНИЕ**: Это удалит ВСЕ финансовые данные!

```sql
-- Выполнить только если нужен полный сброс:
\i sql/reset_all_balances.sql
```

### Шаг 3: Перезапустить приложение
Новый код автоматически будет использовать систему транзакций.

## 🎯 Как работает

### Начисление выплаты
```
1. Админ заполняет форму выплаты
2. Создается запись в `payouts`
3. Вызывается `create_transaction()`
   ├─ Блокируется профиль пользователя
   ├─ Проверяется баланс
   ├─ Создается transaction с type='payout'
   └─ Баланс увеличивается атомарно
4. ID транзакции сохраняется в metadata
```

### Отмена выплаты
```
1. Админ нажимает "Удалить" на выплате
2. Ищется связанная транзакция по reference_id
3. Вызывается `cancel_transaction()`
   ├─ Проверка: были ли выводы после?
   ├─ Проверка: достаточно ли средств?
   ├─ Создается обратная транзакция (correction)
   ├─ Баланс уменьшается
   └─ Исходная транзакция помечается cancelled
4. Выплата удаляется из `payouts`
```

### Вывод средств
```
1. Пользователь создает заявку на вывод
2. Средства замораживаются (создается withdrawal transaction)
3. Админ обрабатывает:
   - Approved → средства остаются замороженными
   - Rejected → создается refund transaction, деньги возвращаются
   - Completed → деньги считаются выплаченными
```

## 🔒 Защита от конфликтов

### 1. Уникальные ID транзакций
- UUID гарантирует уникальность
- Невозможно создать дубликат

### 2. Блокировки базы данных
- FOR UPDATE блокирует строку профиля
- Concurrent операции выполняются последовательно
- Race conditions невозможны

### 3. Проверки целостности
- Баланс всегда совпадает с последней транзакцией
- История транзакций неизменна (только добавление)
- Отмены записываются отдельно, не удаляют историю

### 4. Referential Integrity
- transaction.reference_id → payout.id или withdrawal.id
- Cascade delete удалит транзакции при удалении профиля
- Orphan transactions невозможны

## 📊 Аудит и отчеты

### Баланс пользователя
```sql
SELECT 
  user_id,
  SUM(CASE WHEN type IN ('payout', 'refund') THEN amount ELSE -amount END) as calculated_balance
FROM transactions
WHERE status = 'completed'
GROUP BY user_id;
```

### История операций
```sql
SELECT 
  t.*,
  p.nickname,
  p.email
FROM transactions t
JOIN profiles p ON p.id = t.user_id
ORDER BY t.created_at DESC;
```

### Отмененные транзакции
```sql
SELECT 
  t.*,
  canceller.email as cancelled_by_email
FROM transactions t
LEFT JOIN profiles canceller ON canceller.id = t.cancelled_by
WHERE t.status = 'cancelled'
ORDER BY t.cancelled_at DESC;
```

## ⚠️ Важные замечания

1. **Старые выплаты** - выплаты созданные до внедрения системы не имеют связанных транзакций. Их отмена недоступна.

2. **Миграция** - для миграции старых данных нужен отдельный скрипт (не включен).

3. **Откаты** - транзакции нельзя удалить, только отменить. История сохраняется полностью.

4. **Производительность** - индексы созданы на всех ключевых полях. Запросы быстрые даже с миллионами транзакций.

## 🐛 Отладка

### Несоответствие баланса
```sql
-- Найти пользователей с несоответствием:
SELECT 
  p.id,
  p.email,
  p.balance as current_balance,
  COALESCE(SUM(CASE 
    WHEN t.type IN ('payout', 'refund') THEN t.amount 
    ELSE -t.amount 
  END), 0) as calculated_balance,
  p.balance - COALESCE(SUM(CASE 
    WHEN t.type IN ('payout', 'refund') THEN t.amount 
    ELSE -t.amount 
  END), 0) as difference
FROM profiles p
LEFT JOIN transactions t ON t.user_id = p.id AND t.status = 'completed'
GROUP BY p.id
HAVING ABS(p.balance - COALESCE(SUM(CASE 
  WHEN t.type IN ('payout', 'refund') THEN t.amount 
  ELSE -t.amount 
END), 0)) > 0.01;
```

### Исправить баланс вручную
```sql
-- Создать корректирующую транзакцию:
SELECT create_transaction(
  'USER_UUID'::uuid,
  'correction',
  100.00, -- сумма коррекции
  NULL,
  NULL,
  'Ручная коррекция баланса',
  '{"reason": "Admin correction"}'::jsonb,
  'ADMIN_UUID'::uuid
);
```
