# 🔧 Исправление проблемы с повторной регистрацией email

## Проблема
Когда email был ранее зарегистрирован, но аккаунт был удален из таблицы `profiles`, пользователь все еще может существовать в `auth.users`. При попытке повторной регистрации письмо может не отправляться.

## Что было исправлено

### 1. Код регистрации (app/auth/page.tsx)
- ✅ Добавлена обработка ошибки "User already registered"
- ✅ Автоматическая повторная отправка письма, если email уже существует
- ✅ Пользователь получает уведомление о повторной отправке

### 2. Настройки Supabase (ОБЯЗАТЕЛЬНО!)

#### Шаг 1: Authentication Settings
1. Откройте **Supabase Dashboard** → **Authentication** → **Providers** → **Email**
2. Убедитесь что включено:
   - ✅ **Enable Email provider**
   - ✅ **Confirm email** (должно быть ВКЛЮЧЕНО!)
   - ✅ **Allow duplicate emails** (ВЫКЛЮЧЕНО - по умолчанию)

#### Шаг 2: Auth Settings для повторных регистраций
1. Откройте **Supabase Dashboard** → **Settings** → **Authentication**
2. Найдите раздел **User Signups**:
   - ✅ **Enable email confirmations** - ВКЛЮЧЕНО
   - ⚠️ **Enable manual account linking** - можно ВЫКЛЮЧИТЬ

#### Шаг 3: ВАЖНО - Очистка "мертвых" аккаунтов

Если email был использован ранее, нужно либо:

**Вариант А: Полное удаление старого пользователя**
```sql
-- В Supabase SQL Editor:
-- ВНИМАНИЕ: Удаляет пользователя ПОЛНОСТЬЮ из auth.users
DELETE FROM auth.users WHERE email = 'example@email.com';
DELETE FROM profiles WHERE email = 'example@email.com';
```

**Вариант Б: Сброс подтверждения (лучший вариант)**
```sql
-- Позволяет отправить письмо повторно без удаления
-- ВНИМАНИЕ: confirmed_at - это generated column, не трогаем её!
UPDATE auth.users 
SET 
  email_confirmed_at = NULL,
  updated_at = NOW()
WHERE email = 'example@email.com';
```

После этого пользователь сможет зарегистрироваться заново и получить письмо.

### 3. Проверка работы SMTP

Убедитесь что SMTP настроен правильно:

1. **Settings** → **Auth** → **SMTP Settings**
   ```
   Host: smtp-relay.brevo.com
   Port: 587
   Username: maksbroska@gmail.com
   Password: xsmtpsib-ваш_ключ
   Sender email: littlehikai@gmail.com
   Sender name: thqlabel
   ```

2. Проверьте логи: **Logs** → **Auth Logs**
   - Ищите ошибки типа `smtp failed`, `email send failed`

### 4. Тестирование

1. Попробуйте зарегистрироваться с email, который был ранее удален
2. Система должна:
   - Отправить письмо повторно
   - Показать уведомление "Письмо с подтверждением отправлено повторно"
   - Перевести на экран ожидания подтверждения

3. Проверьте почту (включая спам!)

## Как работает исправление

```typescript
// Старый код (НЕ работал):
await supabase.auth.signUp({ email, password });
// ❌ Если email уже существует - ошибка, письмо не отправляется

// Новый код (РАБОТАЕТ):
const { error } = await supabase.auth.signUp({ email, password });

if (error?.message?.includes('already registered')) {
  // ✅ Отправляем письмо повторно
  await supabase.auth.resend({ type: 'signup', email });
  showNotification('Письмо отправлено повторно');
}
```

## Частые проблемы и решения

### Проблема 1: Письмо все равно не приходит
**Решение:**
1. Проверьте логи Supabase: **Logs** → **Auth Logs**
2. Проверьте Brevo: [app.brevo.com](https://app.brevo.com) → **Campaigns** → **Transactional**
3. Убедитесь что SMTP ключ действителен

### Проблема 2: Ошибка "User already registered"
**Решение:**
- Код теперь автоматически обрабатывает эту ошибку
- Письмо отправляется повторно
- Если не помогло - выполните SQL из "Вариант Б" выше

### Проблема 3: Email подтвержден, но профиль не создается
**Решение:**
Проверьте триггер создания профиля:
```sql
-- Триггер должен создавать профиль автоматически
SELECT * FROM profiles WHERE id = 'user_id';

-- Если профиля нет - проверьте триггер:
SELECT trigger_name, event_manipulation, event_object_table 
FROM information_schema.triggers 
WHERE event_object_table = 'users' 
AND event_object_schema = 'auth';
```

## Дополнительные улучшения (опционально)

### Автоматическая очистка неподтвержденных аккаунтов

Можно настроить автоматическое удаление аккаунтов, которые не подтвердили email за 7 дней:

```sql
-- Создать функцию очистки
CREATE OR REPLACE FUNCTION cleanup_unconfirmed_users()
RETURNS void AS $$
BEGIN
  DELETE FROM auth.users 
  WHERE email_confirmed_at IS NULL 
  AND created_at < NOW() - INTERVAL '7 days';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Настроить pg_cron для запуска каждый день
-- (требуется расширение pg_cron)
```

## Итог

✅ Код исправлен и обрабатывает повторные регистрации
✅ Письма теперь отправляются даже для существующих email
✅ Пользователь получает четкие уведомления
✅ Система стабильно работает с "переиспользованными" email
