# ✅ Basic Release Flow - Готово!

## Что реализовано:

### 1. **Форма создания релиза для Basic** 
[release-basic/create/page.tsx](vsls:/app/cabinet/release-basic/create/page.tsx)
- 7 шагов заполнения (как у Exclusive)
- State для всех данных: треки, платформы, страны, коллабораторы и т.д.

### 2. **Интеграция с базой данных**
[SendStep.tsx](vsls:/app/cabinet/release-basic/create/components/SendStep.tsx)
- Загрузка обложки в `release-covers` bucket
- Сохранение всех данных релиза в таблицу `releases`
- **user_role**: `'basic'`
- **payment_status**: `'verified'` (т.к. оплата прошла при нажатии "Добавить релиз")
- **status**: `'pending'` (на модерации)

### 3. **Передача данных между компонентами**
- [CountriesStep.tsx](vsls:/app/cabinet/release-basic/create/components/CountriesStep.tsx) - список выбранных стран
- [PlatformsStep.tsx](vsls:/app/cabinet/release-basic/create/components/PlatformsStep.tsx) - список выбранных платформ
- Все данные передаются в SendStep для сохранения

## 📊 Как работает флоу:

### Для Basic пользователя:

1. **Кабинет → Релизы → "Добавить релиз"**
   - Открывается модалка оплаты ([UserReleases.tsx](vsls:/app/cabinet/components/UserReleases.tsx))
   - Реквизиты: 500₽, карта/СБП
   
2. **Загрузка чека оплаты**
   - Файл сохраняется в `payment-receipts/{user_id}/{timestamp}`
   - Создается предварительная запись в `releases`:
     - `user_role: 'basic'`
     - `payment_status: 'pending'`
     - `payment_receipt_url: [ссылка на чек]`
     - `status: 'draft'`

3. **Редирект на форму создания релиза**
   - `/cabinet/release-basic/create`
   - Заполнение 7 шагов

4. **Нажатие "Отправить на модерацию"**
   - Загрузка обложки в `release-covers`
   - Обновление/создание записи в `releases`:
     - Все данные релиза (треки, платформы, страны...)
     - `payment_status: 'verified'` ✅
     - `status: 'pending'`

5. **Админ панель**
   - Админ видит релиз с меткой **BASIC**
   - Проверяет чек оплаты (уже verified)
   - Утверждает или отклоняет релиз

## 🔧 Что нужно настроить:

1. **Выполнить SQL скрипты**:
   ```bash
   sql/update_releases_for_moderation.sql
   sql/CREATE_STORAGE_BUCKETS.sql
   ```

2. **Проверить Storage buckets в Supabase**:
   - `release-covers` (для обложек)
   - `payment-receipts` (для чеков)

## ⚡ Готово к использованию!

Basic пользователи теперь могут:
- ✅ Оплатить 500₽ и загрузить чек
- ✅ Создать релиз через 7-шаговую форму
- ✅ Отправить на модерацию
- ✅ Админы увидят релиз в панели модерации
