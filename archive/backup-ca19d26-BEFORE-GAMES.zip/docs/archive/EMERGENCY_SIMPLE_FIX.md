# 🚨 ЭКСТРЕННОЕ ВОССТАНОВЛЕНИЕ - ПРОСТОЕ РЕШЕНИЕ

## ЧТО ДЕЛАТЬ СЕЙЧАС:

### 1️⃣ ОТКРОЙТЕ SUPABASE
https://supabase.com/dashboard/project/jfbuicudlyiwcrllduai/sql

### 2️⃣ ВЫПОЛНИТЕ СКРИПТ
Откройте файл: **sql/SIMPLE_FIX.sql**

Скопируйте ВСЁ и выполните одной кнопкой "Run"

### 3️⃣ ОЧИСТИТЕ КЕШ БРАУЗЕРА
- Нажмите `Ctrl + Shift + Delete`
- Выберите "Всё время"
- Отметьте: Файлы cookie, Кэш
- Нажмите "Удалить данные"

### 4️⃣ ЗАКРОЙТЕ ВСЕ ВКЛАДКИ С САЙТОМ

### 5️⃣ ЗАПУСТИТЕ СЕРВЕР ЗАНОВО
```powershell
# Остановите старый процесс
Get-Process -Name node -ErrorAction SilentlyContinue | Stop-Process -Force

# Перейдите в папку
cd "C:\Users\Asus\Downloads\Telegram Desktop\thq-label"

# Запустите
npm run dev
```

### 6️⃣ ОТКРОЙТЕ В ИНКОГНИТО
- `Ctrl + Shift + N` (Chrome)
- Откройте http://localhost:3000

## ЧТО ДЕЛАЕТ СКРИПТ:

✅ Отключает RLS
✅ Удаляет ВСЕ старые политики и триггеры
✅ Устанавливает вашу роль owner (maksbroska@gmail.com)
✅ Создает простые рабочие политики
✅ Включает RLS обратно

## ЕСЛИ НЕ РАБОТАЕТ:

### Проверьте в Supabase SQL Editor:
```sql
SELECT email, role FROM profiles;
```
Должно показать: `maksbroska@gmail.com | owner`

### Проверьте в консоли браузера (F12):
Должны быть логи типа:
```
✅ Профиль найден! Email: maksbroska@gmail.com Роль из БД: owner
```

### Если сайт вообще не открывается:

1. Проверьте что сервер запущен:
```powershell
Get-Process -Name node
```

2. Проверьте файл .env.local (должен содержать):
```
NEXT_PUBLIC_SUPABASE_URL=https://jfbuicudlyiwcrllduai.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_...
```

3. Перезапустите компьютер и попробуйте снова

## БЫСТРАЯ КОМАНДА ДЛЯ ТЕРМИНАЛА:

```powershell
Get-Process -Name node -ErrorAction SilentlyContinue | Stop-Process -Force; cd "C:\Users\Asus\Downloads\Telegram Desktop\thq-label"; npm run dev
```

Скопируйте эту команду и выполните в PowerShell - она остановит старые процессы и запустит сервер заново.
