# 🎫 Новая система поддержки - Live Chat

## 📋 Что нового

### Для пользователей (Cabinet):
- 💬 **Live-режим** - сообщения обновляются мгновенно без перезагрузки
- ⌨️ **Индикатор печати** - видно когда администратор набирает ответ
- 📎 **Прикрепление файлов** - можно отправлять фото, документы
- 🔔 **Уведомления** - всплывающее окно при новом сообщении от поддержки
- 📊 **Статистика тикетов** - статусы, даты, превью последних сообщений
- ✅ **Закрытие тикетов** - пользователь может закрыть решенный вопрос
- 🗄️ **Автоархивация** - закрытые тикеты архивируются через 1 минуту

### Для администраторов (Admin Panel):
- ⚡ **Real-time обновления** - новые сообщения появляются сразу
- 👀 **Typing indicator** - видно когда пользователь печатает
- 📎 **Загрузка файлов** - можно отправлять инструкции, скриншоты
- 👤 **Информация о пользователе** - аватар, ник, email, Member ID
- 📈 **Счетчики непрочитанных** - красные бейджи на тикетах с новыми сообщениями
- 🎨 **Новый дизайн** - современный интерфейс чата
- 🔄 **Статусы** - Открыт / Ответили / Закрыт

## 🛠️ Установка

### 1. Создание таблиц в Supabase

Выполните SQL скрипт:
```bash
sql/create_ticket_messages_system.sql
```

Этот скрипт создаст:
- `ticket_messages` - таблица для сообщений
- `ticket_attachments` - таблица для файлов
- Новые поля в `tickets` (last_message_at, unread_count, is_typing, и т.д.)
- RLS политики для безопасности
- Storage bucket для файлов
- Триггеры для автообновления

### 2. Настройка Storage

В Supabase Dashboard:
1. Перейдите в **Storage**
2. Убедитесь что bucket `ticket-attachments` создан
3. Политики доступа уже настроены через SQL

### 3. Включение Realtime

В Supabase Dashboard:
1. **Database** → **Replication**
2. Включите replication для таблиц:
   - `tickets`
   - `ticket_messages`
   - `ticket_attachments`

### 4. Настройка автоархивации (опционально)

#### Вариант А: Supabase Edge Function (рекомендуется)

1. Создайте Edge Function:
```bash
supabase functions new archive-tickets
```

2. Добавьте код в `supabase/functions/archive-tickets/index.ts`:
```typescript
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

Deno.serve(async () => {
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )
  
  const { data, error } = await supabase.rpc('archive_closed_tickets')
  
  return new Response(
    JSON.stringify({ success: !error, data, error }),
    { headers: { 'Content-Type': 'application/json' } }
  )
})
```

3. Задеплойте функцию:
```bash
supabase functions deploy archive-tickets
```

4. В Supabase Dashboard → **Edge Functions** → настройте Cron:
   - Функция: `archive-tickets`
   - Расписание: `* * * * *` (каждую минуту)

#### Вариант Б: pg_cron (если доступен)

Выполните скрипт:
```bash
sql/setup_ticket_auto_archive.sql
```

### 5. Обновление компонентов

#### Для пользователей:
Новая страница уже создана:
```
app/cabinet/support/page.tsx
```

Добавьте ссылку в меню кабинета:
```tsx
<Link href="/cabinet/support">
  💬 Поддержка
</Link>
```

#### Для администраторов:
Замените старый TicketsTab на новый:

В `app/admin/page.tsx`:
```tsx
import TicketsTabLive from './components/TicketsTabLive';

// В TabButton'ах:
{activeTab === 'tickets' && (
  <TicketsTabLive supabase={supabase} currentUser={currentUser} />
)}
```

## 🎨 Особенности дизайна

### Пользовательская часть:
- Градиентные кнопки (#6050ba → #8b5cf6)
- Список тикетов слева, чат справа
- Красные бейджи для непрочитанных сообщений
- Всплывающие уведомления в правом верхнем углу
- Анимации появления сообщений

### Админская часть:
- Фильтры по статусам (Все/Открытые/Отвеченные/Закрытые)
- Информация о пользователе в шапке чата
- Typing indicator с анимацией точек
- Быстрое изменение статуса тикета
- Загрузка файлов через кнопку скрепки

## 🔄 Как работает Live-режим

### Realtime подписки:
```typescript
// Подписка на новые сообщения
supabase
  .channel('ticket_messages')
  .on('postgres_changes', 
    { event: 'INSERT', schema: 'public', table: 'ticket_messages' },
    (payload) => handleNewMessage(payload.new)
  )
  .subscribe();

// Подписка на изменения тикетов (typing indicator)
supabase
  .channel('tickets_updates')
  .on('postgres_changes',
    { event: 'UPDATE', schema: 'public', table: 'tickets' },
    (payload) => handleTicketUpdate(payload.new)
  )
  .subscribe();
```

### Typing Indicator:
- При наборе текста обновляется `is_typing = true` в таблице `tickets`
- Через 2 секунды неактивности автоматически сбрасывается
- Другая сторона видит анимацию "печатает..."

### Уведомления:
- Когда админ отправляет сообщение → пользователю показывается уведомление
- Клик на уведомление → открывается тикет
- Автоматическое скрытие через 5 секунд

### Автоархивация:
- Пользователь закрывает тикет → статус меняется на 'closed'
- Через 1 минуту → Edge Function/Cron переносит в архив
- Архивные тикеты не показываются в списке

## 📦 Файловая структура

```
app/
  cabinet/
    support/
      page.tsx          # Новая страница поддержки для пользователей
  admin/
    components/
      TicketsTabLive.tsx  # Новая админская панель тикетов

sql/
  create_ticket_messages_system.sql    # Создание таблиц и RLS
  setup_ticket_auto_archive.sql        # Настройка автоархивации

supabase/
  functions/
    archive-tickets/
      index.ts          # Edge Function для автоархивации (опционально)
```

## 🔒 Безопасность (RLS)

Политики настроены так что:
- Пользователи видят только свои тикеты и сообщения
- Админы видят все тикеты
- Файлы доступны только участникам тикета
- Нельзя читать чужую переписку

## ⚡ Производительность

- Индексы на `ticket_id`, `created_at` для быстрых запросов
- Lazy loading сообщений (загружаются только при открытии тикета)
- Debounce на typing indicator (обновление раз в 2 секунды)
- Оптимизированные RLS запросы

## 🐛 Возможные проблемы

### Realtime не работает:
1. Проверьте что Replication включен для таблиц
2. Убедитесь что API ключи правильные
3. Проверьте консоль браузера на ошибки подключения

### Файлы не загружаются:
1. Проверьте Storage bucket создан
2. Убедитесь что RLS политики применены
3. Проверьте размер файла (макс 5MB по умолчанию)

### Typing indicator не показывается:
1. Проверьте что Realtime подписка на `tickets` активна
2. Убедитесь что `is_typing` обновляется в БД

### Архивация не работает:
1. Проверьте что Edge Function задеплоена
2. Убедитесь что Cron настроен правильно
3. Проверьте логи функции в Dashboard

## 📝 Следующие шаги

1. ✅ Выполните SQL скрипты
2. ✅ Включите Realtime replication
3. ✅ Настройте Edge Function для архивации
4. ✅ Обновите компоненты в коде
5. ✅ Протестируйте live-обновления
6. ✅ Проверьте загрузку файлов
7. ✅ Убедитесь что уведомления работают

## 🎉 Готово!

Теперь у вас полноценная система поддержки с:
- Live-чатом без перезагрузок
- Файловыми вложениями
- Уведомлениями
- Индикаторами печати
- Автоархивацией

При возникновении вопросов смотрите комментарии в коде и RLS политики в БД.
