# 🔧 ИСПРАВЛЕНИЯ И ОБНОВЛЕНИЯ

## ✅ Что было исправлено

### 1. **Ошибка RLS (Row Level Security)** 🔒
**Проблема:** `new row violates row-level security policy for table "linked_accounts"`

**Решение:**
- Обновлены политики RLS в `sql/CREATE_LINKED_ACCOUNTS_TABLE.sql`
- Добавлена проверка `auth.uid()` в политиках INSERT/UPDATE
- Добавлен `WITH CHECK` для политики UPDATE
- Политика SELECT теперь разрешает видеть связи как для `primary_user_id`, так и для `linked_user_id`

**Что нужно сделать:**
```sql
-- Выполните обновленный SQL скрипт в Supabase SQL Editor:
-- 1. Откройте файл: sql/CREATE_LINKED_ACCOUNTS_TABLE.sql
-- 2. Скопируйте всё содержимое
-- 3. Вставьте в Supabase SQL Editor
-- 4. Нажмите Run
```

### 2. **Перевод интерфейса на русский** 🇷🇺

Все компоненты переведены на русский язык (кроме названий ролей Owner/Admin/Exclusive/Basic):

#### AdminRoleHUD.tsx:
- ✅ "Режим тестирования" (вместо "Testing Mode")
- ✅ "Истинная роль" (вместо "Original")
- ✅ "Переключиться на роль" (вместо "Switch to role")
- ✅ "Вернуться к Owner/Admin" (вместо "Return to...")
- ✅ "Переключение роли..." (вместо "Switching role...")

#### AccountManager.tsx:
- ✅ "Сохраненные аккаунты" (вместо "Saved accounts")
- ✅ "Переключить" (вместо "Switch")
- ✅ "Добавить аккаунт" (вместо "Add Account")
- ✅ "Добавление аккаунта" (вместо "Add Account")
- ✅ "Email аккаунта для добавления" (вместо "Email of account to add")
- ✅ "Пароль" (вместо "Password")
- ✅ "Связать аккаунт" (вместо "Link Account")
- ✅ "Связывание..." (вместо "Linking...")
- ✅ Все подсказки и информационные сообщения

#### SettingsTab.tsx:
- ✅ "Настройки" (вместо "Settings")
- ✅ "Управление профилем и настройками" (вместо "Manage your profile and preferences")
- ✅ "Аватар профиля" (вместо "Profile Avatar")
- ✅ "Изменить" (вместо "Change")
- ✅ "Никнейм артиста" (вместо "Artist Nickname")
- ✅ "ID участника (тег)" (вместо "Member ID (Tag)")
- ✅ "Статус аккаунта" (вместо "Account Status")
- ✅ "Тема интерфейса" (вместо "Interface Theme")
- ✅ "Безопасность" (вместо "Security")
- ✅ "Выйти" (вместо "Sign Out")
- ✅ "Управление аккаунтами" (вместо "Account Management")
- ✅ "Доступ Owner" (вместо "Owner Access")

## 📋 Инструкция по применению изменений

### Шаг 1: Обновить базу данных
```sql
-- В Supabase SQL Editor выполните:

-- Удаляем старые политики
DROP POLICY IF EXISTS "Users can view their own linked accounts" ON public.linked_accounts;
DROP POLICY IF EXISTS "Users can create their own linked accounts" ON public.linked_accounts;
DROP POLICY IF EXISTS "Users can delete their own linked accounts" ON public.linked_accounts;
DROP POLICY IF EXISTS "Users can update their linked accounts" ON public.linked_accounts;

-- Создаем новые (из файла CREATE_LINKED_ACCOUNTS_TABLE.sql)
-- Скопируйте секцию "ШАГ 3: ВКЛЮЧЕНИЕ RLS" из файла
```

### Шаг 2: Перезапустить приложение
```bash
# Остановите dev-сервер (Ctrl+C)
# Очистите кэш
Remove-Item -Recurse -Force .next

# Запустите заново
npm run dev
```

### Шаг 3: Проверить работу
1. Откройте **Settings** в личном кабинете
2. Проверьте, что весь текст на русском
3. Попробуйте добавить аккаунт в разделе "Управление аккаунтами"
4. Ошибка RLS должна исчезнуть

## 🔍 Технические детали исправлений

### RLS политики (до и после)

**До:**
```sql
CREATE POLICY "Users can create their own linked accounts"
ON public.linked_accounts
FOR INSERT
WITH CHECK (
  auth.uid() = primary_user_id
);

CREATE POLICY "Users can update their linked accounts"
ON public.linked_accounts
FOR UPDATE
USING (
  auth.uid() = primary_user_id
);
```

**После:**
```sql
CREATE POLICY "Users can create their own linked accounts"
ON public.linked_accounts
FOR INSERT
WITH CHECK (
  auth.uid() = primary_user_id  -- Проверка при INSERT
);

CREATE POLICY "Users can update their linked accounts"
ON public.linked_accounts
FOR UPDATE
USING (
  auth.uid() = primary_user_id  -- Проверка существующей строки
)
WITH CHECK (
  auth.uid() = primary_user_id  -- Проверка новых значений
);
```

**Ключевое отличие:**
- Добавлен `WITH CHECK` в политику UPDATE
- SELECT теперь разрешает видеть связи двум сторонам (`primary_user_id OR linked_user_id`)
- Удаление старых политик перед созданием новых (избегаем конфликтов)

## ⚠️ Возможные проблемы и решения

### Проблема 1: Ошибка RLS всё ещё появляется
**Решение:**
```sql
-- Проверьте, что политики обновились
SELECT policyname, cmd, qual, with_check
FROM pg_policies
WHERE tablename = 'linked_accounts';

-- Если видите старые политики - удалите их вручную
DROP POLICY "old_policy_name" ON public.linked_accounts;

-- Затем создайте новые из файла
```

### Проблема 2: Текст всё ещё на английском
**Решение:**
```bash
# Очистите кэш Next.js
Remove-Item -Recurse -Force .next
Remove-Item -Recurse -Force node_modules/.cache

# Перезапустите
npm run dev
```

### Проблема 3: TypeScript ошибки
**Решение:**
```bash
# Перезапустите TypeScript сервер в VS Code
# Ctrl+Shift+P -> "TypeScript: Restart TS Server"
```

## 📊 Статус изменений

| Компонент | RLS исправлен | Переведен | Протестирован |
|-----------|--------------|-----------|---------------|
| CREATE_LINKED_ACCOUNTS_TABLE.sql | ✅ | - | ⏳ Требуется |
| AdminRoleHUD.tsx | - | ✅ | ✅ |
| AccountManager.tsx | - | ✅ | ⏳ Требуется |
| SettingsTab.tsx | - | ✅ | ✅ |

## 🎯 Следующие шаги

1. **Выполните обновленный SQL скрипт**
2. **Перезапустите приложение**
3. **Протестируйте добавление аккаунта**
4. **Проверьте, что текст на русском**

---

**Всё готово к использованию!** 🎉

Если возникнут проблемы:
1. Проверьте логи в консоли браузера (F12)
2. Проверьте политики RLS в Supabase Dashboard
3. Убедитесь, что кэш очищен

**Дата обновления:** 26 декабря 2024
**Версия:** 1.1.0
