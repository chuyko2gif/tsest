# Инструкция по миграции статуса 'approved' на 'distributed'

## Что изменилось

Статус 'approved' (Одобрен) больше не используется. Теперь используется только статус 'distributed' (На дистрибьюции).

## Шаги для выполнения миграции

### 1. Выполнить SQL миграцию в Supabase

1. Откройте Supabase Dashboard
2. Перейдите в SQL Editor
3. Откройте файл `sql/migrate_approved_to_distributed.sql`
4. Скопируйте весь код
5. Вставьте в SQL Editor
6. Нажмите "Run"

Скрипт выполнит следующие действия:
- Удалит старые ограничения на поле status
- Добавит новые ограничения с поддержкой всех статусов
- Обновит все релизы со статусом 'approved' на 'distributed'
- Покажет результаты миграции

### 2. Проверить результаты

После выполнения миграции должна появиться таблица с результатами:

```
table_name            | distributed_count | approved_count
----------------------|-------------------|---------------
releases_basic        | X                 | 0
releases_exclusive    | Y                 | 0
```

Колонка `approved_count` должна быть равна 0 для обеих таблиц.

### 3. Обновления в коде (уже выполнено)

Следующие файлы были обновлены:
- ✅ `app/admin/components/ReleasesModeration.tsx` - основная админ панель
- ✅ `app/cabinet/components/releases/types.ts` - типы релизов
- ✅ `app/cabinet/components/releases/constants.ts` - константы статусов
- ✅ `app/admin/components/releases/types.ts` - типы админ панели
- ✅ `app/admin/components/tickets/ReleaseInfoModal.tsx` - модальное окно релиза
- ✅ `app/admin/components/tickets/TicketDetailHeader.tsx` - заголовок тикета
- ✅ `app/admin/components/AdminTicketsPanel.tsx` - панель тикетов
- ✅ `app/cabinet/components/releases/ReleaseDetailView.tsx` - детальный просмотр релиза

### 4. Что теперь означают статусы

| Статус | Описание | Цвет |
|--------|----------|------|
| `draft` | Черновик | Серый |
| `pending` | На модерации | Жёлтый |
| `distributed` | На дистрибьюции | Синий 🚀 |
| `published` | Опубликован | Зелёный ✅ |
| `rejected` | Отклонён | Красный ❌ |

### 5. Важно

⚠️ После выполнения SQL миграции **перезапустите приложение** чтобы убедиться, что все изменения применены корректно:

```bash
npm run dev
```

## Проверка работы

1. Откройте админ панель
2. Перейдите в архив релизов
3. Выберите фильтр "На дистрибьюции"
4. Убедитесь, что отображаются все релизы, которые раньше были "Одобрены"
5. Откройте любой релиз - статус должен отображаться как "НА ДИСТРИБЬЮЦИИ" с синим цветом и анимированным значком загрузки

## Откат (если что-то пошло не так)

Если нужно откатить изменения в базе данных, выполните:

```sql
-- Вернуть статусы обратно на 'approved'
UPDATE releases_basic
SET status = 'approved'
WHERE status = 'distributed';

UPDATE releases_exclusive
SET status = 'approved'
WHERE status = 'distributed';
```

Но код придется откатывать через Git.
