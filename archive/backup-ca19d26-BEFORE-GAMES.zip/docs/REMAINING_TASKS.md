# ✅ Выполнено сейчас:

1. ✅ Исправлена проверка минимального количества треков для галочки
2. ✅ Автовыбор всех стран при "Весь мир"
3. ✅ SVG иконки для оплаты и отправки
4. ✅ Передача coverFile в TracklistStep

# 🔄 Нужно доделать вручную:

## В TracklistStep.tsx:

1. Добавить `coverFile?: File | null` в интерфейс props
2. Показывать preview обложки рядом с треками:
```tsx
{coverFile && (
  <img src={URL.createObjectURL(coverFile)} className="w-16 h-16 rounded-lg" />
)}
```

3. Скрыть поле lyrics если инструментал:
```tsx
{!trackIsInstrumental && (
  <div>
    <label>Текст песни</label>
    <textarea value={trackLyrics} .../>
  </div>
)}
```

## В PromoStep.tsx:

4. Сделать окно пропуска промо компактнее - убрать лишние padding

## В PlatformsStep.tsx:

5. Убрать секцию с "Автобуст" и эмодзи

## В PaymentStep.tsx:

6. Заменить эмодзи на SVG иконки

## В базе данных:

7. Добавить поля в drafts:
```sql
ALTER TABLE drafts 
ADD COLUMN IF NOT EXISTS tracks JSONB,
ADD COLUMN IF NOT EXISTS selected_countries TEXT[];
```

## Улучшить дизайн загрузки WAV:

8. В TracklistStep - красивая карточка для аудиофайла с метаданными

# 📝 Приоритет:

1. Обложка в треклисте (высокий)
2. Скрыть lyrics для инструментала (высокий)
3. Черновики БД (критичный)
4. Остальное (средний)
