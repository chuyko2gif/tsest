# 🔗 Система переключения между аккаунтами

## 📋 Описание

Новая система позволяет владельцам (owner) и администраторам (admin) привязывать другие аккаунты и быстро переключаться между ними.

## ✨ Возможности

- ✅ Привязка аккаунтов по email и паролю
- ✅ Быстрое переключение между аккаунтами
- ✅ Просмотр списка связанных аккаунтов
- ✅ Отображение информации о каждом аккаунте (никнейм, роль, avatar)
- ✅ Удаление связанных аккаунтов
- ✅ Доступно только для owner и admin ролей

## 🚀 Установка

### Шаг 1: Запустите SQL миграцию

Выполните файл `sql/SETUP_LINKED_ACCOUNTS_NEW.sql` в вашей базе данных Supabase:

```sql
-- Откройте SQL Editor в Supabase Dashboard
-- Скопируйте содержимое файла SETUP_LINKED_ACCOUNTS_NEW.sql
-- Выполните запрос
```

Это создаст:
- Таблицу `linked_accounts`
- Необходимые индексы
- RLS политики безопасности
- Функцию `get_my_linked_accounts()`

### Шаг 2: Проверьте переменные окружения

Убедитесь, что в `.env.local` есть:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

### Шаг 3: Перезапустите сервер разработки

```bash
npm run dev
```

## 📱 Использование

### Для пользователей

1. **Войдите** как owner или admin
2. Перейдите в **Настройки** (вкладка Settings)
3. В правой колонке найдите секцию **"Связанные аккаунты"**

#### Добавление аккаунта:

1. Нажмите **"+ Добавить аккаунт"**
2. Введите **email** и **пароль** другого аккаунта
3. Нажмите **"Добавить"**
4. Аккаунт появится в списке

#### Переключение на аккаунт:

1. В списке связанных аккаунтов найдите нужный
2. Нажмите **"Переключиться"**
3. Вы будете автоматически выведены из системы
4. Войдите с данными связанного аккаунта

#### Удаление связи:

1. Нажмите иконку **корзины** рядом с аккаунтом
2. Подтвердите удаление

## 🔧 API Endpoints

### GET /api/linked-accounts
Получить список связанных аккаунтов

**Headers:**
```
Authorization: Bearer {access_token}
```

**Response:**
```json
{
  "data": [
    {
      "id": "uuid",
      "linked_user_id": "uuid",
      "linked_email": "test@example.com",
      "created_at": "2025-12-26T...",
      "last_used_at": "2025-12-26T...",
      "profile": {
        "id": "uuid",
        "nickname": "TestUser",
        "avatar": "url",
        "role": "basic",
        "email": "test@example.com",
        "member_id": "THQ-123"
      }
    }
  ]
}
```

### POST /api/linked-accounts
Добавить связанный аккаунт

**Headers:**
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Body:**
```json
{
  "email": "test@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "data": {
    "id": "uuid",
    "primary_user_id": "uuid",
    "linked_user_id": "uuid",
    "linked_email": "test@example.com",
    "linked_nickname": "TestUser",
    "created_at": "2025-12-26T...",
    "profile": { ... }
  }
}
```

### DELETE /api/linked-accounts?linkId={uuid}
Удалить связанный аккаунт

**Headers:**
```
Authorization: Bearer {access_token}
```

**Response:**
```json
{
  "success": true
}
```

### POST /api/switch-account
Переключиться на связанный аккаунт

**Headers:**
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Body:**
```json
{
  "linkedUserId": "uuid"
}
```

**Response:**
```json
{
  "success": true,
  "userId": "uuid",
  "email": "test@example.com",
  "profile": { ... },
  "switchMethod": "redirect"
}
```

## 🛡️ Безопасность

### Проверка прав доступа

- ✅ Только **owner** и **admin** могут управлять связанными аккаунтами
- ✅ Пользователь видит только свои связанные аккаунты
- ✅ Нельзя связать аккаунт сам с собой
- ✅ Проверка подлинности через email и пароль при добавлении
- ✅ RLS политики на уровне базы данных

### Row Level Security (RLS)

Политики безопасности:
- `SELECT`: только свои записи (`primary_user_id = auth.uid()`)
- `INSERT`: только owner/admin + primary_user_id = auth.uid()
- `UPDATE`: только owner/admin + primary_user_id = auth.uid()
- `DELETE`: только owner/admin + primary_user_id = auth.uid()

## 📊 Структура базы данных

### Таблица: linked_accounts

| Колонка | Тип | Описание |
|---------|-----|----------|
| id | UUID | Первичный ключ |
| primary_user_id | UUID | ID основного пользователя (owner/admin) |
| linked_user_id | UUID | ID связанного аккаунта |
| linked_email | TEXT | Email связанного аккаунта |
| linked_nickname | TEXT | Никнейм для отображения |
| created_at | TIMESTAMPTZ | Дата создания связи |
| last_used_at | TIMESTAMPTZ | Последнее использование |

### Constraints:
- `UNIQUE(primary_user_id, linked_user_id)` - уникальность связи
- `CHECK (primary_user_id != linked_user_id)` - нельзя связать сам с собой

## 🎨 Компоненты

### LinkedAccountsManager
Главный компонент управления связанными аккаунтами

**Расположение:** `app/cabinet/components/LinkedAccountsManager.tsx`

**Props:**
```typescript
interface LinkedAccountsManagerProps {
  onShowNotification: (message: string, type: 'success' | 'error') => void;
}
```

**Функции:**
- Отображение списка связанных аккаунтов
- Форма добавления нового аккаунта
- Переключение между аккаунтами
- Удаление связей

## ⚠️ Важные замечания

1. **При переключении аккаунта:**
   - Текущая сессия будет завершена
   - Пользователь будет перенаправлен на страницу входа
   - Необходимо войти с данными связанного аккаунта

2. **Добавление аккаунта:**
   - Требуется email и пароль
   - Проверяется подлинность через Supabase Auth
   - Нельзя добавить свой собственный аккаунт

3. **Безопасность:**
   - Пароли не хранятся
   - Используется только для одноразовой проверки
   - Все операции проходят через защищенный API

## 🐛 Решение проблем

### Ошибка: "Access denied"
- Убедитесь, что ваша роль - `owner` или `admin`
- Проверьте в таблице `profiles` значение поля `role`

### Ошибка: "Invalid credentials"
- Проверьте правильность email и пароля
- Убедитесь, что аккаунт существует в системе

### Не отображается кнопка "Добавить аккаунт"
- Проверьте вашу роль (должна быть owner или admin)
- Откройте консоль браузера для проверки ошибок

### Аккаунт не добавляется
- Проверьте наличие SUPABASE_SERVICE_ROLE_KEY в .env.local
- Проверьте выполнение SQL миграции
- Проверьте RLS политики в Supabase Dashboard

## 📝 Changelog

### v1.0.0 (2025-12-26)
- ✅ Полная переработка системы
- ✅ Новый UI компонент
- ✅ API endpoints
- ✅ SQL миграции
- ✅ Проверка безопасности через email/password
- ✅ Документация

## 🔮 Будущие улучшения

- [ ] Автоматическое переключение без повторного входа
- [ ] История переключений
- [ ] Групповое управление аккаунтами
- [ ] Уведомления при переключении
- [ ] 2FA поддержка

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи в консоли браузера
2. Проверьте логи сервера
3. Проверьте настройки в Supabase Dashboard
4. Обратитесь к разработчику
