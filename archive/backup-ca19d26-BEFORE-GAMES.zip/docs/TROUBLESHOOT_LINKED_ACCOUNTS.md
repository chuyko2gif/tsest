# 🔧 ДИАГНОСТИКА И ИСПРАВЛЕНИЕ ОШИБКИ

## ❌ Ошибка: "Unexpected token '<', "<!DOCTYPE"..."

Эта ошибка означает, что API возвращает HTML вместо JSON.

## 📋 ШАГ ЗА ШАГОМ - ИСПРАВЛЕНИЕ:

### 1️⃣ Проверьте переменные окружения

Откройте файл `.env.local` и убедитесь что есть ВСЕ эти переменные:

```env
NEXT_PUBLIC_SUPABASE_URL=https://ваш-проект.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=ваш_anon_key
SUPABASE_SERVICE_ROLE_KEY=ваш_service_role_key
```

**Где взять ключи:**
1. Откройте Supabase Dashboard
2. Settings → API
3. Скопируйте:
   - Project URL → `NEXT_PUBLIC_SUPABASE_URL`
   - anon/public key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - service_role key → `SUPABASE_SERVICE_ROLE_KEY`

### 2️⃣ Выполните SQL скрипт

**ОБЯЗАТЕЛЬНО!** Запустите SQL миграцию:

1. Откройте Supabase Dashboard
2. SQL Editor → New Query
3. Скопируйте **ВЕСЬ** файл `sql/COMPLETE_LINKED_ACCOUNTS_SETUP.sql`
4. Вставьте в SQL Editor
5. Нажмите **RUN**
6. Дождитесь сообщения: ✅ УСТАНОВКА ЗАВЕРШЕНА УСПЕШНО!

### 3️⃣ Проверьте таблицу в базе данных

1. Откройте Supabase Dashboard
2. Table Editor
3. Найдите таблицу **`linked_accounts`**
4. Если её НЕТ - вернитесь к шагу 2

### 4️⃣ Перезапустите сервер

```bash
# Остановите сервер (Ctrl+C)
# Очистите кеш Next.js
Remove-Item -Recurse -Force .next

# Запустите снова
npm run dev
```

### 5️⃣ Проверьте работу системы

Откройте в браузере:
```
http://localhost:3000/api/linked-accounts/health
```

**Ожидаемый ответ:**
```json
{
  "status": "ok",
  "message": "Linked accounts system is ready",
  "details": { ... }
}
```

**Если ошибка:**
```json
{
  "status": "error",
  "message": "Table does not exist...",
  "solution": "Run the SQL script..."
}
```
→ Вернитесь к шагу 2

### 6️⃣ Войдите в приложение

1. Войдите как **owner** или **admin**
2. Кабинет → Настройки
3. Проверьте секцию "Связанные аккаунты"

## 🐛 ЧАСТЫЕ ПРОБЛЕМЫ:

### Проблема: Таблица не создается

**Решение:**
1. Проверьте что у вас есть права в Supabase
2. Убедитесь что скопировали ВЕСЬ SQL файл
3. Проверьте вывод в SQL Editor на ошибки

### Проблема: "Access denied" / "Permission denied"

**Решение:**
1. Откройте Table Editor → `profiles`
2. Найдите свою запись (по email)
3. Измените `role` на `'owner'`
4. Сохраните
5. Перезайдите в приложение

### Проблема: Переменные окружения не работают

**Решение:**
1. Убедитесь что файл называется `.env.local` (НЕ `.env`)
2. Проверьте что файл в корне проекта
3. Перезапустите сервер ПОЛНОСТЬЮ (Ctrl+C и npm run dev)
4. Проверьте что нет пробелов в ключах

### Проблема: "SUPABASE_SERVICE_ROLE_KEY not found"

**Решение:**
1. Откройте Supabase Dashboard → Settings → API
2. Скопируйте `service_role` key (НЕ anon key!)
3. Добавьте в `.env.local`:
   ```
   SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...ваш_ключ
   ```
4. Перезапустите сервер

## ✅ ЧЕКЛИСТ ПРОВЕРКИ:

- [ ] Файл `.env.local` существует
- [ ] Все 3 переменные окружения заполнены
- [ ] SQL скрипт выполнен успешно
- [ ] Таблица `linked_accounts` видна в Table Editor
- [ ] Сервер перезапущен
- [ ] `/api/linked-accounts/health` возвращает `"status": "ok"`
- [ ] Роль пользователя = `owner` или `admin`

## 📞 Если ничего не помогло:

1. Откройте консоль браузера (F12)
2. Перейдите на вкладку Network
3. Попробуйте открыть раздел "Связанные аккаунты"
4. Найдите запрос к `/api/linked-accounts`
5. Посмотрите Response - там будет детальная ошибка

Пришлите полный текст ошибки из Response.
