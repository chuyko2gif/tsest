# 🎯 БЫСТРЫЙ ЗАПУСК: Drag & Drop для черновиков

## ⚡ ТРИ ПРОСТЫХ ШАГА

### 📌 ШАГ 1: SQL в Supabase (2 минуты)

```
1. Открой: https://supabase.com → Твой проект → SQL Editor
2. Скопируй файл: sql/SIMPLE_DRAFT_ORDERING.sql
3. Вставь в SQL Editor и нажми RUN
4. Должно быть: ✅ Success
```

**Альтернатива:** Если не работает, используй `sql/MINIMAL_DRAFT_ORDER.sql`

---

### 🚀 ШАГ 2: Перезапусти приложение

```bash
# Останови (Ctrl+C) и запусти снова:
npm run dev
```

---

### ✅ ШАГ 3: Проверь работу

1. Открой сайт в браузере
2. Зайди в **"Архив (Черновики)"**
3. **Перетащи черновик** мышью
4. **Обнови страницу** (F5)
5. Порядок сохранился? **ГОТОВО!** 🎉

---

## 🐛 Не работает?

### Проверка 1: SQL выполнился?

Открой Supabase SQL Editor и выполни:
```sql
SELECT column_name FROM information_schema.columns 
WHERE table_name = 'releases_basic' AND column_name = 'draft_order';
```

**Должно вернуть:** `draft_order`

Если пусто → SQL не выполнился! Попробуй `sql/MINIMAL_DRAFT_ORDER.sql`

### Проверка 2: Функция создана?

```sql
SELECT routine_name FROM information_schema.routines 
WHERE routine_name = 'reorder_draft_release';
```

**Должно вернуть:** `reorder_draft_release`

### Проверка 3: Консоль браузера

Нажми **F12** → вкладка **Console**

Перетащи черновик. Если ошибка:
- `function reorder_draft_release does not exist` → SQL не выполнился
- `permission denied` → не даны права, выполни:
  ```sql
  GRANT EXECUTE ON FUNCTION reorder_draft_release TO authenticated;
  ```

---

## 📁 Файлы для установки

1. **`sql/SIMPLE_DRAFT_ORDERING.sql`** - основная версия ⭐
2. **`sql/MINIMAL_DRAFT_ORDER.sql`** - упрощенная версия
3. **`sql/README_INSTALL.md`** - подробная инструкция

---

## 💪 Уже сделано в коде

Фронтенд **УЖЕ ГОТОВ**! Изменены файлы:
- ✅ `app/cabinet/components/UserReleases.tsx`
- ✅ `app/cabinet/components/releases/ReleasesGrid.tsx`
- ✅ `app/cabinet/components/releases/ReleaseCard.tsx`
- ✅ `app/cabinet/components/releases/hooks.ts`

**Нужно только выполнить SQL!**

---

## 🎁 Что получишь

- 🖱️ Drag & Drop работает
- 💾 Порядок сохраняется в базе
- 🚫 Нет пустоты при перетаскивании
- 🔄 Работает после перезагрузки

---

## 📞 Нужна помощь?

Смотри детальную инструкцию: **`sql/README_INSTALL.md`**

Там 3 варианта установки + решение всех ошибок!
