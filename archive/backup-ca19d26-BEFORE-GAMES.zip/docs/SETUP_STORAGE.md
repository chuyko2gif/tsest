# 🗂️ Настройка Supabase Storage для загрузки изображений

## Если bucket 'avatars' уже существует - пропусти этот файл

---

## Создание Storage Bucket

### ШАГ 1: Открой Supabase Dashboard
1. Перейди на https://supabase.com/dashboard
2. Выбери свой проект
3. В левом меню выбери **Storage**

### ШАГ 2: Создай bucket 'avatars' (если его нет)
1. Нажми кнопку **"New bucket"**
2. Заполни форму:
   - **Name:** `avatars`
   - **Public bucket:** ✅ (обязательно поставь галочку!)
3. Нажми **"Create bucket"**

### ШАГ 3: Настрой политики доступа
Перейди в созданный bucket `avatars` → **Policies** и добавь следующие политики:

#### Политика 1: Публичное чтение
```sql
CREATE POLICY "Public Access"
ON storage.objects FOR SELECT
USING ( bucket_id = 'avatars' );
```

#### Политика 2: Аутентифицированные пользователи могут загружать
```sql
CREATE POLICY "Authenticated users can upload"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK ( bucket_id = 'avatars' );
```

#### Политика 3: Пользователи могут обновлять свои файлы
```sql
CREATE POLICY "Users can update own files"
ON storage.objects FOR UPDATE
TO authenticated
USING ( bucket_id = 'avatars' )
WITH CHECK ( bucket_id = 'avatars' );
```

#### Политика 4: Пользователи могут удалять свои файлы
```sql
CREATE POLICY "Users can delete own files"
ON storage.objects FOR DELETE
TO authenticated
USING ( bucket_id = 'avatars' );
```

---

## ⚠️ ВАЖНО!

Без bucket `avatars` загрузка изображений **НЕ БУДЕТ РАБОТАТЬ**!

Убедись что:
1. ✅ Bucket создан
2. ✅ Bucket публичный (Public bucket: ON)
3. ✅ Политики настроены

---

## Готово! 🎉

Теперь можно:
- Загружать изображения в новостях
- Загружать аватарки пользователей
- Все файлы будут храниться в Supabase Storage

Вернись к файлу **SETUP_NEWS_DRAFTS.md** для продолжения настройки.
