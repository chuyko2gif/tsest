"use client";
import React, { useState, useEffect, useRef } from 'react';
import AnimatedBackground from '@/components/AnimatedBackground';
import { useTheme } from '@/contexts/ThemeContext';

// Компонент для анимированного счетчика
const AnimatedCounter = ({ value, className }: { value: number; className?: string }) => {
  const [displayValue, setDisplayValue] = useState(value);
  const [isAnimating, setIsAnimating] = useState(false);
  
  useEffect(() => {
    if (displayValue !== value) {
      setIsAnimating(true);
      const diff = value - displayValue;
      const step = diff / 10;
      let current = displayValue;
      
      const interval = setInterval(() => {
        current += step;
        if ((step > 0 && current >= value) || (step < 0 && current <= value)) {
          setDisplayValue(value);
          setIsAnimating(false);
          clearInterval(interval);
        } else {
          setDisplayValue(Math.round(current));
        }
      }, 30);
      
      return () => clearInterval(interval);
    }
  }, [value, displayValue]);
  
  return (
    <span className={`${className} ${isAnimating ? 'animate-pulse' : ''}`}>
      {displayValue.toLocaleString('ru-RU')}
    </span>
  );
};

interface ReleaseTypeSelectorProps {
  onSelectType: (type: 'single' | 'ep' | 'album', tracksCount?: number) => void;
  onBack: () => void;
}

export default function ReleaseTypeSelector({ onSelectType, onBack }: ReleaseTypeSelectorProps) {
  const [epTracks, setEpTracks] = useState(2); // 2-7
  const [albumTracks, setAlbumTracks] = useState(8); // 8-50
  const { themeName } = useTheme();
  const isLight = themeName === 'light';
  
  const epPrice = epTracks * 300;
  const albumPrice = albumTracks * 300;
  
  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 pt-20 bg-black">
      <AnimatedBackground />
      {/* Тёмный overlay для светлой темы */}
      {isLight && <div className="fixed inset-0 bg-black/5 z-10" />}

      <div className="max-w-6xl w-full relative z-20">
        {/* Заголовок */}
        <div className="text-center mb-5">
          <h1 className="text-3xl font-black mb-2 text-white">
            Выберите тип релиза
          </h1>
          <p className="text-sm text-white/70">
            Каждый формат создан для воплощения вашего звучания
          </p>
        </div>

        {/* Карточки выбора */}
        <div className="grid md:grid-cols-3 gap-5">
          {/* Сингл */}
          <button
            onClick={() => onSelectType('single', 1)}
            className={`group relative rounded-2xl p-5 text-left overflow-hidden transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1 will-change-transform backdrop-blur-xl border shadow-xl ${
              isLight 
                ? 'bg-[rgba(25,25,30,0.75)] border-purple-500/30 hover:border-purple-500/70 hover:shadow-purple-500/30' 
                : 'bg-gradient-to-br from-zinc-900/90 via-zinc-900/80 to-black/90 border-zinc-800/50 hover:border-purple-500/70 hover:shadow-purple-500/20'
            }`}
          >
            {/* Фон карточки с анимированными градиентами */}
            <div className="absolute inset-0 bg-gradient-to-br from-purple-900/30 via-transparent to-transparent rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="absolute -top-20 -right-20 w-40 h-40 bg-purple-500/10 rounded-full blur-3xl group-hover:bg-purple-500/20 transition-all duration-700" />
            
            {/* Светящийся эффект при наведении */}
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />
            
            {/* Блик */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
            </div>
            
            {/* Бейдж ХИТ */}
            <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-purple-500/30 to-pink-500/30 backdrop-blur-sm rounded-full text-[10px] font-bold text-purple-300 border border-purple-400/40 shadow-lg shadow-purple-500/20">
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
              ХИТ
            </div>
            
            <div className="relative z-10">
              {/* Icon с музыкальной ноткой */}
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-purple-800 rounded-lg flex items-center justify-center mb-2 group-hover:scale-110 transition-all duration-300 shadow-lg shadow-purple-500/30">
                <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 18V5l12-2v13" />
                  <circle cx="6" cy="18" r="3" />
                  <circle cx="18" cy="16" r="3" />
                </svg>
              </div>

              {/* Заголовок */}
              <h3 className="text-lg font-black mb-1 text-white group-hover:text-purple-300 transition-colors duration-300">Сингл</h3>
              <p className="text-zinc-400 text-[11px] mb-3 group-hover:text-zinc-300 transition-colors font-medium">
                Один мощный трек
              </p>

              {/* Особенности */}
              <div className="space-y-1.5 mb-3">
                <div className="flex items-center gap-2 text-xs">
                  <div className="w-4 h-4 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0">
                    <svg className="w-2.5 h-2.5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="3">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="font-bold text-white">1 трек</span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <div className="w-4 h-4 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0">
                    <svg className="w-2.5 h-2.5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="3">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                    </svg>
                  </div>
                  <span className="font-bold text-purple-400">500 ₽</span>
                </div>
              </div>

              {/* Итоговая стоимость */}
              <div className="mb-2 p-2 bg-purple-500/10 rounded-lg border border-purple-500/20 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wide">Итого</span>
                  <span className="text-base font-black text-purple-400">500 ₽</span>
                </div>
              </div>

              {/* Кнопка выбора */}
              <div className="flex items-center justify-between px-2.5 py-1.5 bg-gradient-to-r from-purple-600/20 to-purple-600/5 rounded-lg border border-purple-500/30 group-hover:border-purple-500 group-hover:bg-purple-600/30 transition-all duration-300">
                <span className="text-xs font-bold text-white">Выбрать</span>
                <svg className="w-4 h-4 text-purple-400 group-hover:text-white transform group-hover:translate-x-1 transition-all" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>
          </button>

          {/* EP */}
          <button
            onClick={() => onSelectType('ep', epTracks)}
            className={`group relative rounded-2xl p-5 text-left overflow-hidden transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1 will-change-transform backdrop-blur-xl border shadow-xl ${
              isLight 
                ? 'bg-[rgba(25,25,30,0.75)] border-blue-500/30 hover:border-blue-500/70 hover:shadow-blue-500/30' 
                : 'bg-gradient-to-br from-zinc-900/90 via-zinc-900/80 to-black/90 border-zinc-800/50 hover:border-blue-500/70 hover:shadow-blue-500/20'
            }`}
          >
            {/* Фон карточки с анимированными градиентами */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-900/30 via-transparent to-transparent rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="absolute -top-20 -right-20 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl group-hover:bg-blue-500/20 transition-all duration-700" />
            
            {/* Светящийся эффект при наведении */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />
            
            {/* Блик */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
            </div>
            
            {/* Бейдж ХИТ */}
            <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-blue-500/30 to-cyan-500/30 backdrop-blur-sm rounded-full text-[10px] font-bold text-blue-300 border border-blue-400/40 shadow-lg shadow-blue-500/20">
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
              ХИТ
            </div>
            
            <div className="relative z-10">
              {/* Icon с пластинками */}
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center mb-2 group-hover:scale-110 transition-all duration-300 shadow-lg shadow-blue-500/30">
                <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <circle cx="12" cy="12" r="3" />
                  <path d="M12 2v4M12 18v4M2 12h4M18 12h4" />
                </svg>
              </div>

              {/* Заголовок */}
              <h3 className="text-lg font-black mb-1 text-white group-hover:text-blue-300 transition-colors duration-300">EP</h3>
              <p className="text-zinc-400 text-[11px] mb-2 group-hover:text-zinc-300 transition-colors font-medium">
                Мини-альбом 2-7 треков
              </p>

              {/* Ползунок выбора количества треков */}
              <div className="mb-2 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-semibold text-zinc-400 uppercase tracking-wide">Треков</span>
                  <AnimatedCounter value={epTracks} className="text-lg font-black text-blue-400 tabular-nums" />
                </div>
                
                <div className="relative pt-1" onClick={(e) => e.stopPropagation()}>
                  <input
                    type="range"
                    min="2"
                    max="7"
                    value={epTracks}
                    onChange={(e) => setEpTracks(Number(e.target.value))}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer slider-blue"
                    style={{
                      background: `linear-gradient(to right, rgb(59 130 246) 0%, rgb(59 130 246) ${((epTracks - 2) / 5) * 100}%, rgb(39 39 42) ${((epTracks - 2) / 5) * 100}%, rgb(39 39 42) 100%)`
                    }}
                  />
                  <div className="flex justify-between mt-0.5 text-[9px] text-zinc-600 font-semibold">
                    <span>2</span>
                    <span>7</span>
                  </div>
                </div>
              </div>

              {/* Особенности */}
              <div className="flex items-center gap-2 text-[11px] mb-2">
                <div className="w-4 h-4 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0">
                  <svg className="w-2.5 h-2.5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="3">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                </div>
                <span className="font-bold text-blue-400">300 ₽/трек</span>
              </div>

              {/* Итоговая стоимость */}
              <div className="mb-2 p-2 bg-gradient-to-br from-blue-500/20 to-blue-500/5 rounded-lg border border-blue-500/30 backdrop-blur-sm transition-all duration-300">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-semibold text-zinc-400 uppercase tracking-wide">Итого</span>
                  <div className="flex items-center gap-0.5">
                    <AnimatedCounter value={epPrice} className="text-base font-black text-blue-400 tabular-nums" />
                    <span className="text-base font-black text-blue-400">₽</span>
                  </div>
                </div>
              </div>

              {/* Кнопка выбора */}
              <div className="flex items-center justify-between px-2.5 py-1.5 bg-gradient-to-r from-blue-600/20 to-blue-600/5 rounded-lg border border-blue-500/30 group-hover:border-blue-500 group-hover:bg-blue-600/30 transition-all duration-300">
                <span className="text-xs font-bold text-white">Выбрать</span>
                <svg className="w-4 h-4 text-blue-400 group-hover:text-white transform group-hover:translate-x-1 transition-all" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>
          </button>

          {/* Альбом */}
          <button
            onClick={() => onSelectType('album', albumTracks)}
            className={`group relative rounded-2xl p-5 text-left overflow-hidden transition-all duration-500 hover:scale-[1.02] hover:-translate-y-1 will-change-transform backdrop-blur-xl border shadow-xl ${
              isLight 
                ? 'bg-[rgba(25,25,30,0.75)] border-emerald-500/30 hover:border-emerald-500/70 hover:shadow-emerald-500/30' 
                : 'bg-gradient-to-br from-zinc-900/90 via-zinc-900/80 to-black/90 border-zinc-800/50 hover:border-emerald-500/70 hover:shadow-emerald-500/20'
            }`}
          >
            {/* Фон карточки с анимированными градиентами */}
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-900/30 via-transparent to-transparent rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="absolute -top-20 -right-20 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl group-hover:bg-emerald-500/20 transition-all duration-700" />
            
            {/* Светящий эффект при наведении */}
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />
            
            {/* Блик */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
            </div>
            
            {/* Бейдж ЛУЧШЕЕ */}
            <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-emerald-500/30 to-teal-500/30 backdrop-blur-sm rounded-full text-[10px] font-bold text-emerald-300 border border-emerald-400/40 shadow-lg shadow-emerald-500/20">
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              ЛУЧШЕЕ
            </div>
            
            <div className="relative z-10">
              {/* Icon с альбомом */}
              <div className="w-10 h-10 bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-lg flex items-center justify-center mb-2 group-hover:scale-110 transition-all duration-300 shadow-lg shadow-emerald-500/30">
                <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M2 6h4M2 10h4M2 14h4M2 18h4" />
                  <rect x="8" y="4" width="14" height="16" rx="2" />
                  <line x1="12" y1="9" x2="18" y2="9" />
                  <line x1="12" y1="13" x2="18" y2="13" />
                  <line x1="12" y1="17" x2="18" y2="17" />
                </svg>
              </div>

              {/* Заголовок */}
              <h3 className="text-lg font-black mb-1 text-white group-hover:text-emerald-300 transition-colors duration-300">Альбом</h3>
              <p className="text-zinc-400 text-[11px] mb-2 group-hover:text-zinc-300 transition-colors font-medium">
                Полный релиз 8-50 треков
              </p>

              {/* Ползунок выбора количества треков */}
              <div className="mb-2 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-semibold text-zinc-400 uppercase tracking-wide">Треков</span>
                  <AnimatedCounter value={albumTracks} className="text-lg font-black text-emerald-400 tabular-nums" />
                </div>
                
                <div className="relative pt-1" onClick={(e) => e.stopPropagation()}>
                  <input
                    type="range"
                    min="8"
                    max="50"
                    value={albumTracks}
                    onChange={(e) => setAlbumTracks(Number(e.target.value))}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer slider-emerald"
                    style={{
                      background: `linear-gradient(to right, rgb(52 211 153) 0%, rgb(52 211 153) ${((albumTracks - 8) / 42) * 100}%, rgb(39 39 42) ${((albumTracks - 8) / 42) * 100}%, rgb(39 39 42) 100%)`
                    }}
                  />
                  <div className="flex justify-between mt-0.5 text-[9px] text-zinc-600 font-semibold">
                    <span>8</span>
                    <span>50</span>
                  </div>
                </div>
              </div>

              {/* Особенности */}
              <div className="flex items-center gap-2 text-[11px] mb-2">
                <div className="w-4 h-4 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                  <svg className="w-2.5 h-2.5 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="3">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                  </svg>
                </div>
                <span className="font-bold text-emerald-400">300 ₽/трек</span>
              </div>

              {/* Итоговая стоимость */}
              <div className="mb-2 p-2 bg-gradient-to-br from-emerald-500/20 to-emerald-500/5 rounded-lg border border-emerald-500/30 backdrop-blur-sm transition-all duration-300">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-semibold text-zinc-400 uppercase tracking-wide">Итого</span>
                  <div className="flex items-center gap-0.5">
                    <AnimatedCounter value={albumPrice} className="text-base font-black text-emerald-400 tabular-nums" />
                    <span className="text-base font-black text-emerald-400">₽</span>
                  </div>
                </div>
              </div>

              {/* Кнопка выбора */}
              <div className="flex items-center justify-between px-2.5 py-1.5 bg-gradient-to-r from-emerald-600/20 to-emerald-600/5 rounded-lg border border-emerald-500/30 group-hover:border-emerald-500 group-hover:bg-emerald-600/30 transition-all duration-300">
                <span className="text-xs font-bold text-white">Выбрать</span>
                <svg className="w-4 h-4 text-emerald-400 group-hover:text-white transform group-hover:translate-x-1 transition-all" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </div>
            </div>
          </button>
        </div>

        {/* Подсказка */}
        <div className="mt-5 flex justify-center">
          <div className={`inline-flex items-center gap-2.5 px-5 py-2.5 backdrop-blur-xl border rounded-xl shadow-lg ${
            isLight 
              ? 'bg-[rgba(25,25,30,0.75)] border-purple-500/30' 
              : 'bg-zinc-900/80 border-zinc-800'
          }`}>
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center shrink-0">
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <p className="text-sm text-white">
              EP от <span className="text-blue-400 font-bold">2</span>, Альбом от <span className="text-emerald-400 font-bold">8</span> треков
            </p>
          </div>
        </div>

        {/* Кнопка Назад */}
        <div className="mt-4 flex justify-center">
          <button
            onClick={onBack}
            className={`group flex items-center gap-2.5 px-5 py-2.5 backdrop-blur-xl border rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl ${
              isLight 
                ? 'bg-[rgba(25,25,30,0.75)] hover:bg-[rgba(25,25,30,0.85)] border-purple-500/30 hover:border-purple-500/50' 
                : 'bg-zinc-900/80 hover:bg-zinc-800 border-zinc-800 hover:border-zinc-700'
            }`}
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-purple-600 to-purple-800 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <svg className="w-4 h-4 text-white group-hover:-translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </div>
            <span className="text-sm font-bold text-white">Назад</span>
          </button>
        </div>
      </div>
    </div>
  );
}
