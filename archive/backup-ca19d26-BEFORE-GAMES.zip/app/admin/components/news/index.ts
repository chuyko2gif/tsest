// Экспорт компонентов для управления новостями
export * from './types';
export { NewsEditorForm } from './NewsEditorForm';
export { NewsList } from './NewsList';
export { NewsNotifications } from './NewsNotifications';
export { default as NewsTab } from './NewsTab';
